:orphan:


Genie Parsed Command
==============================


..  literalinclude:: ../../../playbooks/genie_parsed_command.yml
    :language: yaml