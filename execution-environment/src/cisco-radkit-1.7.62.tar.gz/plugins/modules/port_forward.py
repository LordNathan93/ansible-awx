#!/usr/bin/python
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)
from __future__ import absolute_import, division, print_function

DOCUMENTATION = """
---
module: port_forward
short_description: Forwards a port on a device in RADKIT inventory to localhost port.
version_added: "0.3.0"
description:
  - This module forwards a port on a device in RADKIT inventory to local port so that connections can be made with other modules by changing port.
  - Exposed local ports are unprotected (there is no way to add an authentication layer, as these are raw TCP sockets).
  - In the case of port forwarding, no credentials are used from the RADKit service and must be configured locally on ansible client side.
options:
    device_name:
        description:
            - Name of device as it shows in RADKit inventory
        required: True
        type: str
    local_port:
        description:
            - Port on localhost to open
        required: True
        type: int
    destination_port:
        description:
            - Port on remote device to connect. Port must be configured to be forwarded in RADKIT inventory.
        required: True
        type: int
    test:
        description:
            - Tests your configuration before trying to run in async
        type: bool
        default: False
extends_documentation_fragment: cisco.radkit.radkit_client
requirements:
    - radkit
author: Scott Dozier (@scdozier)
"""

EXAMPLES = """
# The idea of this module is to start the module once and run on localhost for duration of the play.
# Any other module running on the localhost can utilize it to connect to devices over the opened port.
#
# This example utilizes port forwarding to connect to multiple hosts at a time. Each host will have ssh
# port forwarded to a port on the localhost (host 1 = 4000, host 2, 4001, etc). The port must be allowed
# for forwarding in the RADKIT inventory.
---
- hosts: all
  become: no
  gather_facts: no
  vars:
    # This is the base port, each host will be 4000 + index (4000, 4001, etc)
    local_port_base_num: 4000
    # in this example, we will forward ssh port
    destination_port: 22
    ansible_ssh_host: 127.0.0.1
  pre_tasks:
    - name: Get a host index number from ansible_hosts
      set_fact:
        host_index: "{{ lookup('ansible.utils.index_of', data=ansible_play_hosts, test='eq', value=inventory_hostname, wantlist=True)[0] }}"
      delegate_to: localhost

    - name: Create local_port var
      set_fact:
        local_port: "{{ local_port_base_num|int + host_index|int }}"
        ansible_ssh_port: "{{ local_port_base_num|int + host_index|int }}"
      delegate_to: localhost

    - name: Test RADKIT Port Forward To Find Potential Config Errors (optional)
      cisco.radkit.port_forward:
        device_name: "{{ inventory_hostname }}"
        local_port: "{{ local_port }}"
        destination_port: "{{ destination_port }}"
        test: True
      delegate_to: localhost

    - name: Start RADKIT Port Forward And Leave Running for 300 Seconds (adjust time based on playbook exec time)
      cisco.radkit.port_forward:
        device_name: "{{ inventory_hostname }}"
        local_port: "{{ local_port }}"
        destination_port: "{{ destination_port }}"
      async: 300
      poll: 0
      delegate_to: localhost

    - name: Wait for local port to become open (it takes a little bit for forward to start)
      ansible.builtin.wait_for:
        port: "{{ local_port }}"
        delay: 3
      delegate_to: localhost
  tasks:

    - name: Example linux module 1 (note; credentials are passed locally)
      service:
        name: sshd
        state: started

    - name: Example linux module 2 (note; credentials are passed locally)
      shell: echo $HOSTNAME
"""
RETURN = r"""
"""
from threading import Event

try:
    from radkit_client.sync import Client

    HAS_RADKIT = True
except ImportError:
    HAS_RADKIT = False
from ansible.module_utils.basic import AnsibleModule
from ansible_collections.cisco.radkit.plugins.module_utils.client import (
    radkit_client_argument_spec,
    RadkitClientService,
)
from ansible_collections.cisco.radkit.plugins.module_utils.exceptions import (
    AnsibleRadkitError,
)

__metaclass__ = type


def run_action(module: AnsibleModule, radkit_service: RadkitClientService):
    """
    Starts port forwarding throgh RADKIT
    """
    results = {}
    err = False
    try:
        ansible = module.params
        # get device from radkit inventory
        inventory = radkit_service.get_inventory_by_filter(
            ansible["device_name"], "name"
        )
        if not inventory:
            raise AnsibleRadkitError(
                f"No devices found in RADKit inventory with attr: 'name' and pattern: {ansible['device_name']}!"
            )
        # open port forward
        port_forwarder = inventory[ansible["device_name"]].forward_tcp_port(
            local_port=ansible["local_port"],
            destination_port=ansible["destination_port"],
        )
        if ansible["test"]:
            results["changed"] = False
            port_forwarder.stop()
        else:
            results["changed"] = True
            # wait forever to keep forwarder open
            Event().wait()

    except Exception as e:
        err = True
        results["msg"] = str(e)
        results["changed"] = False
    return results, err


def main():
    spec = radkit_client_argument_spec()
    spec.update(
        dict(
            device_name=dict(
                type="str",
                required=True,
            ),
            test=dict(
                type="bool",
                default=False,
            ),
            local_port=dict(
                type="int",
                required=True,
            ),
            destination_port=dict(
                type="int",
                required=True,
            ),
        )
    )
    module = AnsibleModule(argument_spec=spec, supports_check_mode=False)
    if not HAS_RADKIT:
        module.fail_json(msg="Python module cisco_radkit is required for this module!")
    with Client.create() as client:
        radkit_service = RadkitClientService(client, module.params)
        results, err = run_action(module, radkit_service)

    if err:
        module.fail_json(**results)
    module.exit_json(**results)


if __name__ == "__main__":
    main()
