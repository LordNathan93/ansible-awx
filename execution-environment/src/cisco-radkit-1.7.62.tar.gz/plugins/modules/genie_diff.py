#!/usr/bin/python
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)
from __future__ import absolute_import, division, print_function

DOCUMENTATION = """
---
module: genie_diff
short_description: This module compares the results across multiple devices and outputs the differences.
version_added: "0.2.0"
description:
  - This module compares the results across multiple devices and outputs the differences between the parsed command output or the learned model output.
  - If diff_snapshots is used, compares differences in results from the same device.
options:
    result_a:
        description:
            - Result A from previous genie_parsed_command
        required: True
        type: dict
    result_b:
        description:
            - Result B from previous genie_parsed_command
        required: True
        type: dict
    diff_snapshots:
        description:
            - Set to true if comparing output from the same device.
        default: False
        type: bool
requirements:
    - radkit
author: Scott Dozier (@scdozier)
"""

RETURN = r"""
genie_diff_result:
    description: Result from Genie Diff
    returned: success
    type: str
genie_diff_result_lines:
    description: Result from Genie Diff split into a list
    returned: success
    type: str
"""
EXAMPLES = """
    - name:  Get show version parsed (initial snapshot)
      cisco.radkit.genie_parsed_command:
        commands: show version
        device_name: daa-csr1
        os: iosxe
      register: cmd_output
      delegate_to: localhost

    - name:  Get show version parsed (2nd snapshot)
      cisco.radkit.genie_parsed_command:
        commands: show version
        device_name: daa-csr1
        os: iosxe
      register: cmd_output2
      delegate_to: localhost

    - name:  Get a diff from snapshots daa-csr1
      cisco.radkit.genie_diff:
        result_a: "{{ cmd_output }}"
        result_b: "{{ cmd_output2 }}"
        diff_snapshots: yes
      delegate_to: localhost

    - name:  Get show version parsed from routerA
      cisco.radkit.genie_parsed_command:
        commands: show version
        device_name: daa-csr1
        os: iosxe
      register: cmd_output
      delegate_to: localhost

    - name: Get show version parsed from routerB
      cisco.radkit.genie_parsed_command:
        commands: show version
        device_name: daa-csr2
        os: iosxe
      register: cmd_output2
      delegate_to: localhost

    - name:  Get a diff from snapshots of routerA and routerB
      cisco.radkit.genie_diff:
        result_a: "{{ cmd_output }}"
        result_b: "{{ cmd_output2 }}"
        diff_snapshots: no
      delegate_to: localhost

"""
from ansible.module_utils.basic import AnsibleModule

try:
    import radkit_genie

    HAS_RADKIT_GENIE = True
except ImportError:
    HAS_RADKIT_GENIE = False
__metaclass__ = type


def run_action(module: AnsibleModule):
    """
    Runs the radkit_genie diff_snapshots function
    """
    results = {}
    err = False
    try:
        ansible = module.params
        results["ansible_module_results"] = {}
        if (
            isinstance(ansible["result_a"], dict)
            and "genie_parsed_result" in ansible["result_a"]
        ):
            result_a = ansible["result_a"]["genie_parsed_result"]
        else:
            result_a = ansible["result_a"]

        if (
            isinstance(ansible["result_b"], dict)
            and "genie_parsed_result" in ansible["result_b"]
        ):
            result_b = ansible["result_b"]["genie_parsed_result"]
        else:
            result_b = ansible["result_b"]

        if ansible["diff_snapshots"]:
            results["genie_diff_result"] = str(
                radkit_genie.diff_snapshots(result_a, result_b)
            )
        else:
            results["genie_diff_result"] = str(radkit_genie.diff(result_a, result_b))

        results["genie_diff_result_lines"] = results["genie_diff_result"].split("\n")
        results["changed"] = False

    except Exception as e:
        err = True
        results["msg"] = str(e)
        results["changed"] = False

    return results, err


def main():
    spec = dict(
        result_a=dict(
            type="dict",
            required=True,
        ),
        result_b=dict(
            type="dict",
            required=True,
        ),
        diff_snapshots=dict(
            type="bool",
            default=False,
        ),
    )

    module = AnsibleModule(argument_spec=spec, supports_check_mode=False)
    results, err = run_action(module)
    if err:
        module.fail_json(**results)
    module.exit_json(**results)


if __name__ == "__main__":
    main()
