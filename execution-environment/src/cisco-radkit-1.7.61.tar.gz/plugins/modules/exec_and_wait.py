#!/usr/bin/python
# -*- coding: utf-8 -*-

from __future__ import absolute_import, division, print_function

DOCUMENTATION = """
---
module: exec_and_wait
short_description: Executes commands on devices using RADKit and handles interactive prompts
version_added: "1.7.61"
description:
  - This module runs commands on specified devices using RADKit, handling interactive prompts with pexpect.
options:
    device_name:
        description:
            - Name of the device as it appears in the RADKit inventory. Use either device_name or device_host.
        required: False
        type: str
    device_host:
        description:
            - Hostname or IP address of the device as it appears in the RADKit inventory. Use either device_name or device_host.
        required: False
        type: str
    commands:
        description:
            - List of commands to execute on the device.
        required: False
        type: list
        elements: str
    prompts:
        description:
            - List of expected prompts to handle interactively.
        required: False
        type: list
        elements: str
    answers:
        description:
            - List of answers corresponding to the expected prompts.
        required: False
        type: list
        elements: str
    command_timeout:
        description:
            - Time in seconds to wait for a command to complete.
        required: False
        default: 15
        type: int
    seconds_to_wait:
        description:
            - Maximum time in seconds to wait after sending the commands before checking the device state.
        required: True
        type: int
    delay_before_check:
        description:
            - Delay in seconds before performing a final check on the device state.
        required: False
        default: 10
        type: int
extends_documentation_fragment: cisco.radkit.radkit_client
requirements:
    - radkit
author: Scott Dozier (@scdozier)
"""
RETURN = r"""
device_name:
    description: Device in Radkit
    returned: success
    type: str
executed_commands:
    description: Command
    returned: success
    type: list
stdout:
    description: Output of commands
    returned: success
    type: str
"""
EXAMPLES = """
    - name: Reload Router and Wait Until Available by using ansible_host
      cisco.radkit.exec_and_wait:
        #device_name: "{{inventory_hostname}}"
        device_host: "{{ansible_host}}"
        commands:
          - "reload"
        prompts:
          - ".*yes/no].*"
          - ".*confirm].*"
        answers:
          - "yes\r"
          - "\r"
        seconds_to_wait: 300  # total time to wait for reload
        delay_before_check: 10  # Delay before checking terminal
      register: reload_result

    - name: Reload Router and Wait Until Available by using inventory_hostname
      cisco.radkit.exec_and_wait:
        device_name: "{{inventory_hostname}}"
        commands:
          - "reload"
        prompts:
          - ".*yes/no].*"
          - ".*confirm].*"
        answers:
          - "yes\r"
          - "\r"
        seconds_to_wait: 300  # total time to wait for reload
        delay_before_check: 10  # Delay before checking terminal
      register: reload_result

    - name: Reset the Connection
      # The connection must be reset to allow Ansible to poll the router for connectivity
      meta: reset_connection
"""
import time
from ansible.module_utils.basic import AnsibleModule
from ansible_collections.cisco.radkit.plugins.module_utils.client import (
    radkit_client_argument_spec,
    RadkitClientService,
)
from ansible_collections.cisco.radkit.plugins.module_utils.exceptions import (
    AnsibleRadkitError,
)

__metaclass__ = type

try:
    from radkit_client.sync import Client

    HAS_RADKIT = True
except ImportError:
    HAS_RADKIT = False


import time
import re
import pexpect
import socket

def wait_for_terminal_connection(device, inventory, max_attempts=30, retry_interval=1):
    """Waits for the terminal to become connected, recreating it if needed."""
    terminal = inventory[device].terminal()

    for attempt in range(max_attempts):
        if terminal.status.value == 'CONNECTED':
            return terminal  # Successfully connected
        time.sleep(retry_interval)

    # Final check after recreation
    if terminal.status.value != 'CONNECTED':
        terminal.close()
        raise AnsibleRadkitError(f"Device {device} terminal failed to connect after retries and recreation.")
    return None

def run_action(module: AnsibleModule, radkit_service: RadkitClientService):
    """
    Runs actions to execute commands via RADKit service using pexpect for interactive handling.
    """
    results = {}
    err = False

    try:
        ansible = module.params
        device_name = ansible["device_name"]
        device_host = ansible["device_host"]
        commands = ansible["commands"]
        prompts = ansible["prompts"]
        answers = ansible["answers"]
        command_timeout = ansible["command_timeout"]
        seconds_to_wait = ansible["seconds_to_wait"]
        delay_before_check = ansible["delay_before_check"]

        # Get the inventory for the specified device
        if device_name:
            inventory = radkit_service.get_inventory_by_filter(device_name, "name")
            if not inventory:
                raise AnsibleRadkitError(
                    f"No devices found in RADKit inventory with name: {device_name}"
                )
        elif device_host:
            inventory = radkit_service.get_inventory_by_filter(device_host, "host")
            if not inventory:
                raise AnsibleRadkitError(
                    f"No devices found in RADKit inventory with name: {device_name}"
                )
        command_results = []
        last_command = None  # Track the last executed command
        executed_commands = []  # Stores the list of executed commands
        full_output = ""  # String to store all stdout together

        for device in inventory:
            terminal = inventory[device].terminal().wait()
            forwarder = terminal.attach_socket()
            child = forwarder.spawn_pexpect()

            if not child.isalive():
                raise AnsibleRadkitError(
                    f"Pexpect session for {device} is not alive after reload!"
                )

            try:
                for command in commands:
                    last_command = command  # Track last command sent
                    executed_commands.append(command)  # Add command to list
                    child.sendline(command)

                    # Allow device to process the command
                    time.sleep(2)

                    while True:
                        # Check if any prompt appears
                        index = child.expect(
                            [re.compile(p) for p in prompts]
                            + [pexpect.TIMEOUT, pexpect.EOF],
                            timeout=command_timeout,
                        )
                        output = child.before.decode("utf-8").strip()
                        if len(prompts) > 1:
                            full_output = f"\n{output}" if output else ""
                        elif len(prompts) == 1:
                            full_output += f"\n{output}" if output else ""
                        else:
                            full_output += ""

                        if index < len(prompts):
                            # Found a matching prompt → Send the corresponding answer
                            answer = answers[index]
                            last_command = answer
                            executed_commands.append(answer)
                            child.sendline(answer)

                            time.sleep(1)

                            # Capture output after sending the answer
                            child.expect([".*"], timeout=command_timeout)
                            full_output += f"\n{child.before.decode('utf-8').strip()}"

                        else:
                            # No more prompts, exit the loop
                            break

            except (
                pexpect.exceptions.EOF,
                pexpect.exceptions.TIMEOUT,
                OSError,
                socket.timeout,
            ):
                # Handle unexpected session disconnection
                if child.before:
                    full_output += f"\n{child.before.decode('utf-8').strip()}"
                else:
                    full_output += "\n"

            # Store results
            results.update(
                {
                    "device_name": device,
                    "executed_commands": executed_commands,  # List of commands executed
                    "stdout": full_output.strip(),  # Combined output as a single string
                    "changed": True,
                }
            )
        if child.isalive():
            try:
                child.close()
            except Exception as e:
                pass

        # Delay before final check
        time.sleep(delay_before_check)
        start_time = time.time()  # Track start time

        for device in inventory:
            reload_complete = False
            while not reload_complete:
                if time.time() - start_time > seconds_to_wait:
                    raise AnsibleRadkitError(
                        f"Device {device} did not respond within {seconds_to_wait} seconds!"
                    )

                try:
                    # Check if terminal is available after reload
                    terminal = wait_for_terminal_connection(device, inventory)
                    reload_complete = True  # Successfully reconnected

                    # Send a newline to ensure we have a prompt
                    inventory[device].exec("\r").wait()
                except Exception:
                    time.sleep(5)  # Wait before retrying
    except Exception as e:
        err = True
        import traceback

        results["msg"] = traceback.format_exc()
        results["exec_status"] = "FAILURE"

    if err:
        module.fail_json(**results)
    module.exit_json(**results)

    return results, err


def main():
    spec = radkit_client_argument_spec()
    spec.update(
        dict(
            device_name=dict(type="str", required=False),
            device_host=dict(type="str", required=False),
            seconds_to_wait=dict(type="int", required=True),
            delay_before_check=dict(type="int", default=10),
            command_timeout=dict(type="int", default=5),
            commands=dict(type="list", elements="str", required=False),
            answers=dict(type="list", elements="str", required=False),
            prompts=dict(type="list", elements="str", required=False),
        )
    )

    module = AnsibleModule(argument_spec=spec, supports_check_mode=False)

    if not HAS_RADKIT:
        module.fail_json(msg="Python module cisco_radkit is required for this module!")

    with Client.create() as client:
        radkit_service = RadkitClientService(client, module.params)
        if not module.params["device_name"] and not module.params["device_host"]:
            module.fail_json(msg="You must specify either a device_name or device_host")
        results, err = run_action(module, radkit_service)

    if err:
        module.fail_json(**results)
    module.exit_json(**results)


if __name__ == "__main__":
    main()
