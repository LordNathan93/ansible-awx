#!/usr/bin/python
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)
from __future__ import (absolute_import, division, print_function)

DOCUMENTATION = '''
---
module: put_file
short_description: Uploads a file to a remote device using SCP or SFTP via RADKit
version_added: "1.7.5"
description:
  - Uploads a file to a remote device using SCP or SFTP via RADKit
options:
    device_name:
        description:
            - Name of device as it shows in RADKit inventory
        required: True
        type: str
    local_path:
        description:
            - Path to the local file to be uploaded
        required: True
        type: str
    remote_path:
        description:
            - Path on the remote device where the file will be uploaded
        required: True
        type: str
    protocol:
        description:
            - Protocol to use for uploading, either scp or sftp
        required: True
        type: str
extends_documentation_fragment: cisco.radkit.radkit_client
requirements:
    - radkit
author: Scott Dozier (@scdozier)
'''

RETURN = r'''
message:
    description: Status message
    type: str
    returned: always
'''

EXAMPLES = '''
- name: Upload file to device using SCP
  put_file:
    device_name: router1
    local_path: /path/to/local/file
    remote_path: /path/to/remote/file
    protocol: scp

- name: Upload file to device using SFTP
  put_file:
    device_name: router1
    local_path: /path/to/local/file
    remote_path: /path/to/remote/file
    protocol: sftp
'''

import json
import time
try:
    from radkit_client.sync import Client
    HAS_RADKIT = True
except ImportError:
    HAS_RADKIT = False
from ansible.module_utils.basic import AnsibleModule
from ansible_collections.cisco.radkit.plugins.module_utils.client import radkit_client_argument_spec, RadkitClientService
from ansible_collections.cisco.radkit.plugins.module_utils.exceptions import AnsibleRadkitError

__metaclass__ = type

def run_upload(module: AnsibleModule, radkit_service: RadkitClientService):
    """
    Executes file upload to the remote device using specified protocol
    """
    results = {}
    err = False
    try:
        ansible = module.params
        device_name = ansible['device_name']
        local_path = ansible['local_path']
        remote_path = ansible['remote_path']
        protocol = ansible['protocol'].lower()

        # Validate protocol
        if protocol not in ['scp', 'sftp']:
            raise AnsibleRadkitError('Protocol must be either scp or sftp')

        # Get device inventory
        inventory = radkit_service.get_inventory_by_filter(device_name, 'name')
        if not inventory:
            raise AnsibleRadkitError(f"No devices found in RADKit inventory with attr: 'name' and pattern: {device_name}!")

        # Select upload function based on protocol
        if protocol == 'scp':
            upload_func = inventory[device_name].scp_upload_from_file
        else:
            upload_func = inventory[device_name].sftp_upload_from_file

        # Perform file upload
        result = upload_func(remote_path=remote_path, local_path=local_path).wait()
        while result.result.status.value != 'TRANSFER_DONE':
            time.sleep(0.5)
        results['message'] = f"status:{result.status.value} " + \
                             f"bytes_written:{str(result.bytes_written)}"
        results["changed"] = True

    except Exception as e:
        err = True
        results["msg"] = str(e)
        results["changed"] = False

    return results, err

def main():
    spec = radkit_client_argument_spec()
    spec.update(dict(device_name=dict(type='str', required=True),
                     local_path=dict(type='str', required=True),
                     remote_path=dict(type='str', required=True),
                     protocol=dict(type='str', required=True)
                     )
                )
    module = AnsibleModule(argument_spec=spec, supports_check_mode=False)
    if not HAS_RADKIT:
        module.fail_json(msg='Python module cisco_radkit is required for this module!')
    with Client.create() as client:
        radkit_service = RadkitClientService(client, module.params)
        results, err = run_upload(module, radkit_service)
    if err:
        module.fail_json(**results)
    module.exit_json(**results)

if __name__ == '__main__':
    main()
