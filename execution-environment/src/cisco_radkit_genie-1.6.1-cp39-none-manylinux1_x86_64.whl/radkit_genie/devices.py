# This file is part of RADKit / Lazy Maestro <radkit@cisco.com>
# Copyright (c) 2018-2023 by Cisco Systems, Inc.
# All rights reserved.

# mock a Genie's device object with methods we need to integrate RADKit

from __future__ import annotations

from typing import Any

from genie.conf.base.utils import QDict  # type:ignore[import-untyped]
from genie.libs.conf.device import Device as GenieDevice  # type:ignore[import-untyped]

from radkit_client.sync.device import Device as RADKitDevice
from radkit_client.sync.exceptions import ClientError
from radkit_common import nglog

from .exceptions import RADKitGenieException, RADKitGenieMissingOS
from .settings import get_settings
from .utils import get_ephemeral_attributes

tGENIE = nglog.Tags.GENIE
logger = nglog.getAdapter(__name__, tags=[tGENIE])


class Device(GenieDevice):  # type: ignore[misc] # Class cannot subclass "GenieDevice" (has type "Any")
    """
    RADKitGenie Device object
    """

    def __init__(
        self,
        device: RADKitDevice,
        os: str | None = None,
        exec_timeout: int | None = None,
        **kwargs: Any,
    ) -> None:
        """
        Instantiate Genie device object based on RADKit Device passed.
        """
        self.radkitdevice = device

        if exec_timeout is not None:
            self.exec_timeout = exec_timeout
        else:
            self.exec_timeout = get_settings().exec_timeout

        if os is None:
            device_os = get_ephemeral_attributes(device, "os")
            if not device_os:
                raise RADKitGenieMissingOS(
                    f"{device.name} is missing 'os' information, can't instantiate Device"
                )
        else:
            device_os = os

        # instantiate Genie Device object
        custom = {"abstraction": {"order": ["os"]}}
        super().__init__(device.name, os=device_os, custom=custom, **kwargs)

    def connect(self, *args: Any, **kwargs: Any) -> None:
        pass

    def disconnect(self, *args: Any, **kwargs: Any) -> None:
        pass

    # Overload the execute() method to return device command output
    # back to genie. This is needed for genie learn which interactively
    # collects device command output
    def execute(self, command: str, **kwargs: Any) -> str:
        logger.debug("Executing command", device_name=self.name, command=command)
        timeout = kwargs.get("timeout", self.exec_timeout)
        response = self.radkitdevice.exec(command, timeout=timeout).wait()
        if response.result is not None:
            try:
                return response.result.data
            except ClientError:
                raise RADKitGenieException(
                    f'Error executing "{command}" on device {self.name}: {response.result.status_message}'
                )
        else:
            raise RADKitGenieException(
                f'Unknown error executing "{command}" on device {self.name}'
            )

    # overload parse() method to support genie device api
    # this method is called from radkit_genie.parse() with output set,
    # and from genie's device api without it being set.
    def parse(self, parser: str, output: str | None = None) -> QDict:
        if output is None:
            output = self.execute(parser)
        return super().parse(parser, output=output)
