==================================
Cisco RADKIT Collection
==================================

.. contents:: Topics
v1.8.0
======
From this point forward collection version will match last tested RADKit version

* NEW: added controlapi_device module to add devices to RADKit via ControlAPI. This is a basic implementation, more features will be added in future releases.
Requires Radkit 1.8.0+!

v1.7.5
======
From this point forward collection version will match last tested RADKit version

* NEW: put_file Adds capability to upload file via SCP or SFTP
* Various fixes to fix compability with RADKIT 1.7
Requires Radkit 1.7.5+!

v0.6.1
======
* NEW: network_cli read improvements/fixes for radkit 1.6 compability
* NEW: Added service_info to test status of radkit service and return basic info
* Added additional CI testing, preparing for possible open source release
Requires Radkit 1.6!

v0.5.3
======
Requires Radkit 1.5!
* FIX: Fixed issues with network_cli giving errors while trying to reboot.
* FIX: Fixed issue with network_cli wait_for_connection
* Added additional testing to prepare for open source release

v0.5.0
======
* FIX: Remove deprecated cert_utils references to make compatible with RADKIT 1.5
* NEW: Added SNMP module
Requires Radkit 1.5!


v0.4.1
======
* FIX: Fixed issue where radkit errors with initial were not being displayed with connection plugins
* FIX: Improved network_cli write time
Requires Radkit 1.4!


v0.4.0
======
* NEW: Updated all connection plugins and modules to support changes in RADKit 1.4
* NEW: Added working unit tests for connection plugins
* FIX: Improvement in reliability with network_cli connection plugin.
Requires Radkit 1.4!


v0.3.0
======
* NEW: network_cli performs indpendant sessions, does not rely on exec
* FIX: inventory plugin now generates certificate_bundle

v0.3.0
======
Tested to be working with Radkit 1.3

* FIX: Cleaned unneccessary arguments to network_cli
* FIX: Recreate certificate_bundle dir if missing
* FIX: Fixed wait_for_connection for network devices
* FIX: SCP Copy/Fetch with network_cli is fixed
* NEW: Added raw HTTP module
* NEW: Added HTTP Proxy
* NEW: Added Port Forward module
* NEW: Added Swagger module

v0.2.0
======

* FIX: Corrected issues with some linux based ansible modules like setup (gather_facts).
* NEW: Added more complete documentation with example playbooks
* NEW: Added command module
* NEW: Added genie_diff module
* NEW: Added genie_parsed_command module

v0.1.0
======

First version.
