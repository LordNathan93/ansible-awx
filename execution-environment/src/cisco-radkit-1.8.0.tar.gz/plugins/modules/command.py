#!/usr/bin/python
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)
from __future__ import absolute_import, division, print_function

DOCUMENTATION = """
---
module: command
short_description: Runs a command via RADKit and returns the result
version_added: "0.2.0"
description:
  - Runs a command via RADKit and returns the result
options:
    device_name:
        description:
            - Name of device as it shows in RADKit inventory
        required: False
        type: str
    filter_pattern:
        description:
            - Pattern to match RADKit inventory, which can select multiple devices at once. (use instead of device_name)
        required: False
        type: str
    filter_attr:
        description:
            - Attrbute to match RADKit inventory, which can select multiple devices at once. (use with filter_pattern, ex 'name')
        required: False
        type: str
    commands:
        description:
            - Commands to execute on device
        required: True
        aliases: ['command']
        type: list
        elements: str
    wait_timeout:
        description:
            - Specifies how many seconds RADKit will wait before failing task.
            - Note that the request is not affected, and it will still eventually complete (successfully or unsuccessfully)
            - Can optionally set via environemnt variable RADKIT_ANSIBLE_WAIT_TIMEOUT
        required: False
        default: 0
        type: int
    exec_timeout:
        description:
            - Specifies how many seconds RADKit will for command to complete
            - Can optionally set via environemnt variable RADKIT_ANSIBLE_EXEC_TIMEOUT
        required: False
        default: 0
        type: int
    remove_prompts:
        description:
            - Remove first and last line from output which is usually the cli prompt
        required: False
        default: True
        type: bool
extends_documentation_fragment: cisco.radkit.radkit_client
requirements:
    - radkit
author: Scott Dozier (@scdozier)
"""

RETURN = r"""
device_name:
    description: Device in Radkit
    returned: success
    type: str
command:
    description: Command
    returned: success
    type: str
stdout:
    description: Output of command
    returned: success
    type: str
exec_status:
    description: Status of exec from RADKit
    returned: always
    type: str
exec_status_message:
    description: Status message from RADKit
    returned: always
    type: str
ansible_module_results:
    returned: success
    description: Dictionary of results is returned if running command on multiple devices or multiple commands
    type: dict
"""
EXAMPLES = """
- name: Run Command all devices in inventory starting with router
  cisco.radkit.command:
    filter_attr: name
    filter_pattern: router
    command: show version
  register: cmd_output
  delegate_to: localhost

- name: Run Command on router1
  cisco.radkit.command:
    device_name: router1
    command: show version
  register: cmd_output
  delegate_to: localhost

- name: Show output
  debug:
    msg: "{{ cmd_output.stdout }}"

"""
try:
    from radkit_client.sync import Client

    HAS_RADKIT = True
except ImportError:
    HAS_RADKIT = False
from ansible.module_utils.basic import AnsibleModule
from ansible_collections.cisco.radkit.plugins.module_utils.client import (
    radkit_client_argument_spec,
    RadkitClientService,
)
from ansible_collections.cisco.radkit.plugins.module_utils.exceptions import (
    AnsibleRadkitError,
)
from ansible.module_utils.basic import env_fallback

__metaclass__ = type


def run_action(module: AnsibleModule, radkit_service: RadkitClientService):
    """
    Runs actions to execute commands via radkit service
    """
    results = {}
    err = False
    try:
        ansible = module.params
        results["ansible_module_results"] = {}
        ansible_returned_result = []
        if ansible["device_name"]:
            # running exec on a single device
            inventory = radkit_service.get_inventory_by_filter(
                ansible["device_name"], "name"
            )
            if not inventory:
                raise AnsibleRadkitError(
                    f"No devices found in RADKit inventory with attr: 'name' and pattern: {ansible['device_name']}!"
                )
            response = radkit_service.exec_command(ansible["commands"], inventory)
            radkit_result = response[ansible["device_name"]]
            if radkit_result.status.value != "SUCCESS":
                raise AnsibleRadkitError(f"{radkit_result.status_message}")
            for command in radkit_result:
                cmd_result = radkit_result[command]
                cmd_result_dict = {
                    "device_name": getattr(cmd_result.device, "name", ""),
                    "command": getattr(cmd_result, "command", ""),
                    "exec_status": getattr(cmd_result.status, "value", ""),
                    "exec_status_message": getattr(cmd_result, "status_message", ""),
                    "stdout": getattr(cmd_result, "data", ""),
                }
                if "\n" in cmd_result.data and ansible["remove_prompts"]:
                    cleaned_cmd_output = "".join(
                        cmd_result.data.splitlines(keepends=True)[1:][:-1]
                    ).strip()
                    cmd_result_dict["stdout"] = cleaned_cmd_output
                ansible_returned_result.append(cmd_result_dict)

        else:
            # running exec on multiple devices, returns a list of dicts
            ansible_returned_result = []
            inventory = radkit_service.get_inventory_by_filter(
                ansible["filter_pattern"], ansible["filter_attr"]
            )
            if not inventory:
                raise AnsibleRadkitError(
                    "No devices found in RADKit inventory with attr: "
                    + f"{ansible['filter_attr']} and pattern: {ansible['filter_pattern']}!"
                )
            radkit_result = radkit_service.exec_command(
                ansible["commands"], inventory, return_full_response=True
            )
            device_statuses = set(
                [radkit_result.result[d].status.value for d in radkit_result.result]
            )
            if len(device_statuses) == 1 and list(device_statuses)[0] == "FAILURE":
                err = True
                results[
                    "msg"
                ] = "All devices failed to connect via RADKIT. Check connectivity and/or authentication"
            else:
                for device in radkit_result.result:
                    for command in radkit_result.result[device]:
                        cmd_result = radkit_result.result[device][command]
                        cmd_result_dict = {
                            "device_name": cmd_result.device.name,
                            "command": cmd_result.command,
                            "exec_status": cmd_result.status.value,
                            "exec_status_message": cmd_result.status_message,
                            "stdout": cmd_result.data,
                        }
                        if "\n" in cmd_result.data and ansible["remove_prompts"]:
                            cleaned_cmd_output = "".join(
                                cmd_result.data.splitlines(keepends=True)[1:][:-1]
                            ).strip()
                            cmd_result_dict["stdout"] = cleaned_cmd_output
                        ansible_returned_result.append(cmd_result_dict)
        results["changed"] = False

    except Exception as e:
        err = True
        results["msg"] = str(e)
        results["changed"] = False

    if len(ansible_returned_result) == 1:
        results.update(ansible_returned_result[0])
    elif isinstance(ansible_returned_result, list):
        results["ansible_module_results"] = ansible_returned_result
    return results, err


def main():
    spec = radkit_client_argument_spec()
    spec.update(
        dict(
            commands=dict(
                type="list",
                required=True,
                elements="str",
                aliases=["command"],
            ),
            device_name=dict(
                type="str",
                required=False,
            ),
            filter_pattern=dict(
                type="str",
                required=False,
            ),
            filter_attr=dict(
                type="str",
                required=False,
            ),
            wait_timeout=dict(
                type="int",
                default=0,
                fallback=(env_fallback, ["RADKIT_ANSIBLE_WAIT_TIMEOUT"]),
            ),
            exec_timeout=dict(
                type="int",
                default=0,
                fallback=(env_fallback, ["RADKIT_ANSIBLE_EXEC_TIMEOUT"]),
            ),
            remove_prompts=dict(
                type="bool",
                default=True,
            ),
        )
    )
    module = AnsibleModule(argument_spec=spec, supports_check_mode=False)
    if (
        not module.params["device_name"]
        and not module.params["filter_pattern"]
        and not module.params["filter_attr"]
    ):
        module.fail_json(
            msg="You must provide either argument device_name or filter_pattern+filter_attr"
        )
    if not module.params["device_name"] and (
        module.params["filter_pattern"] and not module.params["filter_attr"]
    ):
        module.fail_json(
            msg="You must provide either provide BOTH filter_pattern and filter_attr"
        )

    if not HAS_RADKIT:
        module.fail_json(msg="Python module cisco_radkit is required for this module!")
    with Client.create() as client:
        radkit_service = RadkitClientService(client, module.params)
        results, err = run_action(module, radkit_service)
    if err:
        module.fail_json(**results)
    module.exit_json(**results)


if __name__ == "__main__":
    main()
