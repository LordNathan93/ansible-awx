#!/usr/bin/python
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)
from __future__ import absolute_import, division, print_function

DOCUMENTATION = """
---
module: swagger
short_description: Interacts with Swagger/OpenAPI via RADKit
version_added: "0.3.0"
description:
  - Interacts with Swagger/OpenAPI via RADKit
options:
    device_name:
        description:
            - Name of device as it shows in RADKit inventory
        required: True
        type: str
    path:
        description:
            - url path, starting with /
        required: True
        type: str
    method:
        description:
            - HTTP method (get,post,put,patch,delete,options,head)
        required: True
        type: str
    parameters:
        description:
            -  HTTP params
        required: False
        type: dict
    json:
        description:
            -  Request body to be encoded as json or None
        required: False
        type: dict
    status_code:
        description:
            - A list of valid, numeric, HTTP status codes that signifies success of the request.
        default: [ 200 ]
        type: list
        elements: int
extends_documentation_fragment: cisco.radkit.radkit_client
requirements:
    - radkit
author: Scott Dozier (@scdozier)
"""

RETURN = r"""
data:
    description: response body content as string
    returned: success
    type: str
json:
    description: response body content decoded as json
    returned: success
    type: dict
status_code:
    description: status
    returned: success
    type: str
"""
EXAMPLES = """
    - name:  Get alarms from vManage
      cisco.radkit.swagger:
        device_name: vmanage1
        path: /alarms
        method: get
        status_code: [200]
        register: swagger_output
      delegate_to: localhost

    - name:  Register a new NMS partner in vManage
      cisco.radkit.swagger:
        device_name: vmanage1
        path: /partner/{partnerType}
        parameters: '{"partnerType": "dnac"}'
        method: post
        status_code: [200]
        json: '{"name": "DNAC-test","partnerId": "dnac-test","description": "dnac-test"}'
      register: swagger_output
      delegate_to: localhost
"""
import json

try:
    from radkit_client.sync import Client

    HAS_RADKIT = True
except ImportError:
    HAS_RADKIT = False
from ansible.module_utils.basic import AnsibleModule
from ansible_collections.cisco.radkit.plugins.module_utils.client import (
    radkit_client_argument_spec,
    RadkitClientService,
)
from ansible_collections.cisco.radkit.plugins.module_utils.exceptions import (
    AnsibleRadkitError,
)

__metaclass__ = type


def run_action(module: AnsibleModule, radkit_service: RadkitClientService):
    """
    Runs actions to execute commands via radkit service
    """
    results = {}
    err = False
    try:
        ansible = module.params
        if ansible["device_name"]:
            # running exec on a single device
            inventory = radkit_service.get_inventory_by_filter(
                ansible["device_name"], "name"
            )
            if not inventory:
                raise AnsibleRadkitError(
                    f"No devices found in RADKit inventory with attr: 'name' and pattern: {ansible['device_name']}!"
                )
            # update swagger paths
            inventory[ansible["device_name"]].update_swagger().wait()
            # run swagger job
            swagger_func = getattr(
                inventory[ansible["device_name"]].swagger, ansible["method"].lower()
            )
            swagger_params = dict(
                path=ansible["path"],
                json=ansible["json"],
                parameters=ansible["parameters"],
            )
            if "json" in swagger_params and swagger_params["json"] is None:
                swagger_params.pop("json")
            radkit_response = swagger_func(**swagger_params).wait()
            results["status_code"] = radkit_response.result.response_code
            results["data"] = radkit_response.result.text
            if (
                hasattr(radkit_response.result, "content_type")
                and "json" in radkit_response.result.content_type.lower()
            ):
                results["json"] = radkit_response.result.json
            if ansible["method"].lower() in ["get", "head"]:
                results["changed"] = False
            else:
                results["changed"] = True
            if radkit_response.result.response_code not in ansible["status_code"]:
                err = True
                results[
                    "msg"
                ] = f"reponse code {radkit_response.result.response_code} not in {ansible['status_code']}"
                results["changed"] = False
        else:
            err = True

    except Exception as e:
        err = True
        results["msg"] = str(e)
        results["changed"] = False

    return results, err


def main():
    spec = radkit_client_argument_spec()
    spec.update(
        dict(
            path=dict(
                type="str",
                required=True,
            ),
            device_name=dict(
                type="str",
                required=True,
            ),
            method=dict(
                type="str",
                required=True,
            ),
            parameters=dict(
                type="dict",
                required=False,
            ),
            json=dict(
                type="dict",
                required=False,
            ),
            status_code=dict(
                type="list",
                elements="int",
                default=[200],
            ),
        )
    )
    module = AnsibleModule(argument_spec=spec, supports_check_mode=False)
    if module.params["method"].lower() not in [
        "post",
        "get",
        "delete",
        "head",
        "put",
        "patch",
    ]:
        module.fail_json(
            msg="HTTP method must be either POST, GET, DELETE, HEAD, PUT, PATCH"
        )
    if not HAS_RADKIT:
        module.fail_json(msg="Python module cisco_radkit is required for this module!")
    with Client.create() as client:
        radkit_service = RadkitClientService(client, module.params)
        results, err = run_action(module, radkit_service)
    if err:
        module.fail_json(**results)
    module.exit_json(**results)


if __name__ == "__main__":
    main()
