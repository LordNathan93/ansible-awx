#!/usr/bin/python
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)
from __future__ import absolute_import, division, print_function

DOCUMENTATION = """
---
module: service_info
short_description: Gets RADKit service information and responds with status
version_added: "0.6.0"
description:
  - Tests reachability to the remote RADKit service and returns information about the service
options:
    ping:
        description:
            - Sends ping RPC messages to the remote Service. Useful as a liveness check.
        default: True
        type: bool
    update_inventory:
        description:
            - Updates the inventory for this Service. This will also refresh the Service capabilities.
        default: True
        type: bool
    update_capabilities:
        description:
            - Updates the capabilities for this Service. The capabilities may change if the remote Service is upgraded/downgraded.
        default: True
        type: bool
extends_documentation_fragment: cisco.radkit.radkit_client
requirements:
    - radkit
author: Scott Dozier (@scdozier)
"""

RETURN = r"""
service_id:
    description: The service ID / serial of service
    returned: success
    type: str
version:
    description: The version of service
    returned: success
    type: str
status:
    description: Returns 'up' or 'down' depending on if the service is reachable
    returned: success
    type: str
capabilities:
    description: List of capabilities of service
    returned: success
    type: list
inventory_length:
    description: Number of devices in inventory
    returned: success
    type: int
e2ee_active:
    description: Returns True E2EE is currently in use when communicating with this Service
    returned: success
    type: bool
e2ee_supported:
    description: Returns True if this Service supports end-to-end encryption (E2EE)
    returned: success
    type: bool
"""
EXAMPLES = """
    - name:  Get RADKit service info
      cisco.radkit.service_info:
        service_serial: abc-def-ghi
      register: service_info
      delegate_to: localhost
"""
try:
    from radkit_client.sync import Client

    HAS_RADKIT = True
except ImportError:
    HAS_RADKIT = False
from ansible.module_utils.basic import AnsibleModule
from ansible_collections.cisco.radkit.plugins.module_utils.client import (
    radkit_client_argument_spec,
    RadkitClientService,
)

__metaclass__ = type


def run_action(module: AnsibleModule):
    """
    Runs actions to get information about remote radkit service
    """
    results = {}
    err = False
    try:
        ansible = module.params
        with Client.create() as client:
            radkit_service = RadkitClientService(client, module.params).radkit_service
            if ansible["ping"]:
                module.debug("Running ping")
                radkit_service.ping()
            if ansible["update_inventory"]:
                module.debug("Running update_inventory")
                radkit_service.update_inventory()
            if ansible["update_capabilities"]:
                module.debug("Running update_capabilities")
                radkit_service.update_capabilities()

            results["inventory_length"] = len(radkit_service.inventory)
            capabilities = radkit_service.capabilities.wait()
            capabilities_list = []
            for capability in capabilities:
                capabilities_list.append(capabilities[capability].name)
            results["capabilities"] = capabilities_list
            results["service_id"] = capabilities.service_id
            results["e2ee_active"]: radkit_service.e2ee_active
            results["e2ee_supported"]: radkit_service.e2ee_supported
            results["version"] = radkit_service.version
            results["changed"] = False
            results["status"] = "up"

    except Exception as e:
        err = True
        results["msg"] = str(e)
        results["changed"] = False
        results["status"] = "down"

    return results, err


def main():

    spec = radkit_client_argument_spec()
    spec.update(
        {
            "ping": {
                "type": "bool",
                "default": True,
            },
            "update_inventory": {
                "type": "bool",
                "default": True,
            },
        },
        update_capabilities={
            "type": "bool",
            "default": True,
        },
    )
    module = AnsibleModule(argument_spec=spec, supports_check_mode=True)

    if not HAS_RADKIT:
        module.fail_json(msg="Python module cisco_radkit is required for this module!")

    results, err = run_action(module)
    if err:
        module.fail_json(**results)
    module.exit_json(**results)


if __name__ == "__main__":
    main()
