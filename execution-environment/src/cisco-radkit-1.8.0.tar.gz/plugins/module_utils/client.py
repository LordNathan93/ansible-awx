from __future__ import absolute_import, division, print_function
import os
import base64
try:
    from packaging import version
    HAS_PACKAGING = True
except ImportError:
    HAS_PACKAGING = False
try:
    import radkit_client
    from radkit_client.sync import Client
    HAS_RADKIT = True
except ImportError:
    HAS_RADKIT = False
from ansible.module_utils.common.warnings import warn
from ansible.module_utils.basic import env_fallback
from ansible.module_utils._text import to_text
from ansible_collections.cisco.radkit.plugins.module_utils.exceptions import AnsibleRadkitError

__metaclass__ = type


def check_if_radkit_version_supported():
    '''
    Function checks if version meets radkit supported version
    '''
    if HAS_PACKAGING:
        if not HAS_RADKIT:
            raise AnsibleRadkitError('RADKIT Client is not installed!')
        current_major_release = '1.8.0b'
        next_major_release = '1.9.0b'
        radkit_version = version.parse(radkit_client.version.version_str)
        next_major = version.parse(next_major_release)
        current_major = version.parse(current_major_release)

        if radkit_version >= next_major or radkit_version < current_major:
            warn(f'This version of the RADKit Ansible collection is only verified in the RADKit 1.8.x release. Installed RADKit version: {radkit_version}')


# Base Argument Spec holds fields common to all radkit related modules
def radkit_client_argument_spec():
    return dict(identity=dict(type='str',
                              aliases=['radkit_identity'],
                              required=True,
                              fallback=(env_fallback, ['RADKIT_ANSIBLE_IDENTITY'])),
                client_key_password_b64=dict(type='str',
                                             required=True,
                                             no_log=True,
                                             aliases=['radkit_client_private_key_password_base64'],
                                             fallback=(env_fallback, ['RADKIT_ANSIBLE_CLIENT_PRIVATE_KEY_PASSWORD_BASE64'])),
                service_serial=dict(type='str',
                                    aliases=['radkit_serial', 'radkit_service_serial'],
                                    required=True,
                                    fallback=(env_fallback, ['RADKIT_ANSIBLE_SERVICE_SERIAL'])),
                client_key_path=dict(type='str',
                                     required=False,
                                     no_log=True,
                                     fallback=(env_fallback, ['RADKIT_ANSIBLE_CLIENT_KEY_PATH'])),
                client_cert_path=dict(type='str',
                                      required=False,
                                      fallback=(env_fallback, ['RADKIT_ANSIBLE_CLIENT_CERT_PATH'])),
                client_ca_path=dict(type='str',
                                    required=False,
                                    fallback=(env_fallback, ['RADKIT_ANSIBLE_CLIENT_CA_PATH'])),
                )


class RadkitClientService:

    def __init__(self, radkit_sync_client, module_params):
        """Constructor method
        """
        check_if_radkit_version_supported()
        for param in module_params:
            setattr(self, param, module_params[param])
        try:
            private_key_password = base64.b64decode((getattr(self, 'client_key_password_b64', None))).decode('utf8')
            radkit_sync_client.certificate_login(identity=getattr(self, 'identity', None),
                                       ca_path=getattr(self, 'client_ca_path', None),
                                       key_path=getattr(self, 'client_key_path', None),
                                       cert_path=getattr(self, 'client_cert_path', None),
                                       private_key_password=private_key_password)
            self.radkit_client = radkit_sync_client
            service = radkit_sync_client.service(getattr(self, 'service_serial', None)).wait()
            self.radkit_service = service

        except Exception as e:
            raise AnsibleRadkitError('Unable to connect to RADKit Service: ' + to_text(e))

    def get_inventory_by_filter(self, pattern, attr):
        ''' Gets inventory from RADKit by pattern and attr

        :returns: inventory
        '''
        inventory = self.radkit_service.inventory.filter(attr, pattern)
        if inventory:
            return inventory
        else:
            raise AnsibleRadkitError(f'No devices found in RADKit inventory with attr: {attr} and pattern: {pattern}!')

    def exec_command(self, cmd, inventory, return_full_response=False):
        ''' Runs a commands on devices via RADKit

        :returns: result
        '''
        if int(getattr(self, 'wait_timeout', 0)) == 0:
            response = inventory.exec(cmd, timeout=int(getattr(self, 'exec_timeout', 0))).wait()
        else:
            response = inventory.exec(cmd, timeout=int(getattr(self, 'exec_timeout', 0))).wait(int(getattr(self, 'wait_timeout', 0)))
        if return_full_response:
            return response
        else:
            return response.result
