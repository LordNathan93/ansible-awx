:orphan:

.. meta::
  :antsibull-docs: 2.16.3

.. _list_of_collection_env_vars:

Index of all Collection Environment Variables
=============================================

The following index documents all environment variables declared by plugins in collections.
Environment variables used by the ansible-core configuration are documented in :ref:`ansible_configuration_settings`.

.. envvar:: ANSIBLE_INVENTORY_USE_EXTRA_VARS

    Merge extra vars into the available variables for composition (highest precedence).

    *Used by:*
    :ansplugin:`cisco.radkit.radkit inventory plugin <cisco.radkit.radkit#inventory>`
.. envvar:: ANSIBLE_NETWORK_CLI_RETRIES

    Number of attempts to connect to remote host. The delay time between the retires increases after every attempt by power of 2 in seconds till either the maximum attempts are exhausted or any of the :literal:`persistent\_command\_timeout` or :literal:`persistent\_connect\_timeout` timers are triggered.

    *Used by:*
    :ansplugin:`cisco.radkit.network\_cli connection plugin <cisco.radkit.network_cli#connection>`
.. envvar:: ANSIBLE_NETWORK_IMPORT_MODULES

    Reduce CPU usage and network module execution time by enabling direct execution. Instead of the module being packaged and executed by the shell, it will be directly executed by the Ansible control node using the same python interpreter as the Ansible process. Note- Incompatible with :literal:`asynchronous mode`. Note- Python 3 and Ansible 2.9.16 or greater required. Note- With Ansible 2.9.x fully qualified modules names are required in tasks.

    *Used by:*
    :ansplugin:`cisco.radkit.network\_cli connection plugin <cisco.radkit.network_cli#connection>`
.. envvar:: ANSIBLE_NETWORK_SINGLE_USER_MODE

    This option enables caching of data fetched from the target for re-use. The cache is invalidated when the target device enters configuration mode.

    Applicable only for platforms where this has been implemented.

    *Used by:*
    :ansplugin:`cisco.radkit.network\_cli connection plugin <cisco.radkit.network_cli#connection>`
.. envvar:: ANSIBLE_PERSISTENT_BUFFER_READ_TIMEOUT

    Configures, in seconds, the amount of time to wait for the data to be read from Radkit interactive session after the command prompt is matched. This timeout value ensures that command prompt matched is correct and there is no more data left to be received from remote host.

    *Used by:*
    :ansplugin:`cisco.radkit.network\_cli connection plugin <cisco.radkit.network_cli#connection>`
.. envvar:: ANSIBLE_PERSISTENT_LOG_MESSAGES

    This flag will enable logging the command executed and response received from target device in the ansible log file. For this option to work 'log\_path' ansible configuration option is required to be set to a file path with write access.

    Be sure to fully understand the security implications of enabling this option as it could create a security vulnerability by logging sensitive information in log file.

    *Used by:*
    :ansplugin:`cisco.radkit.network\_cli connection plugin <cisco.radkit.network_cli#connection>`
.. envvar:: RADKIT_ANSIBLE_CLIENT_CA_PATH

    The path to the issuer chain for the identity certificate

    *Used by:*
    :ansplugin:`cisco.radkit.network\_cli connection plugin <cisco.radkit.network_cli#connection>`,
    :ansplugin:`cisco.radkit.radkit inventory plugin <cisco.radkit.radkit#inventory>`,
    :ansplugin:`cisco.radkit.terminal connection plugin <cisco.radkit.terminal#connection>`
.. envvar:: RADKIT_ANSIBLE_CLIENT_CERT_PATH

    The path to the identity certificate

    *Used by:*
    :ansplugin:`cisco.radkit.network\_cli connection plugin <cisco.radkit.network_cli#connection>`,
    :ansplugin:`cisco.radkit.radkit inventory plugin <cisco.radkit.radkit#inventory>`,
    :ansplugin:`cisco.radkit.terminal connection plugin <cisco.radkit.terminal#connection>`
.. envvar:: RADKIT_ANSIBLE_CLIENT_KEY_PATH

    The path to the private key for the identity certificate

    *Used by:*
    :ansplugin:`cisco.radkit.network\_cli connection plugin <cisco.radkit.network_cli#connection>`,
    :ansplugin:`cisco.radkit.radkit inventory plugin <cisco.radkit.radkit#inventory>`,
    :ansplugin:`cisco.radkit.terminal connection plugin <cisco.radkit.terminal#connection>`
.. envvar:: RADKIT_ANSIBLE_CLIENT_PRIVATE_KEY_PASSWORD_BASE64

    The private key password in base64 for radkit client

    *Used by:*
    :ansplugin:`cisco.radkit.network\_cli connection plugin <cisco.radkit.network_cli#connection>`,
    :ansplugin:`cisco.radkit.radkit inventory plugin <cisco.radkit.radkit#inventory>`,
    :ansplugin:`cisco.radkit.terminal connection plugin <cisco.radkit.terminal#connection>`
.. envvar:: RADKIT_ANSIBLE_DEVICE_FILTER_ATTR

    Filter RADKit inventory by this attribute (ex name)

    *Used by:*
    :ansplugin:`cisco.radkit.radkit inventory plugin <cisco.radkit.radkit#inventory>`
.. envvar:: RADKIT_ANSIBLE_DEVICE_FILTER_PATTERN

    Filter RADKit inventory by this pattern combined with filter\_attr

    *Used by:*
    :ansplugin:`cisco.radkit.radkit inventory plugin <cisco.radkit.radkit#inventory>`
.. envvar:: RADKIT_ANSIBLE_EXEC_TIMEOUT

    Specifies how many seconds RADKit will for wait command to complete

    *Used by:*
    :ansplugin:`cisco.radkit.terminal connection plugin <cisco.radkit.terminal#connection>`
.. envvar:: RADKIT_ANSIBLE_IDENTITY

    The Client ID (owner email address) present in the RADKit client certificate.

    *Used by:*
    :ansplugin:`cisco.radkit.network\_cli connection plugin <cisco.radkit.network_cli#connection>`,
    :ansplugin:`cisco.radkit.radkit inventory plugin <cisco.radkit.radkit#inventory>`,
    :ansplugin:`cisco.radkit.terminal connection plugin <cisco.radkit.terminal#connection>`
.. envvar:: RADKIT_ANSIBLE_SERVICE_SERIAL

    The serial of the RADKit service you wish to connect through

    *Used by:*
    :ansplugin:`cisco.radkit.network\_cli connection plugin <cisco.radkit.network_cli#connection>`,
    :ansplugin:`cisco.radkit.radkit inventory plugin <cisco.radkit.radkit#inventory>`,
    :ansplugin:`cisco.radkit.terminal connection plugin <cisco.radkit.terminal#connection>`
.. envvar:: RADKIT_ANSIBLE_WAIT_TIMEOUT

    Specifies how many seconds RADKit will wait before failing task.

    Note that the request is not affected, and it will still eventually complete (successfully or unsuccessfully)

    *Used by:*
    :ansplugin:`cisco.radkit.terminal connection plugin <cisco.radkit.terminal#connection>`
