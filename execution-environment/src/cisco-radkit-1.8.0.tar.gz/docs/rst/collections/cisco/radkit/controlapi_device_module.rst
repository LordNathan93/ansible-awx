.. Document meta section

:orphan:

.. meta::
  :antsibull-docs: 2.16.3

.. Document body

.. Anchors

.. _ansible_collections.cisco.radkit.controlapi_device_module:

.. Title

cisco.radkit.controlapi_device module
+++++++++++++++++++++++++++++++++++++


The documentation for the module plugin, cisco.radkit.controlapi_device,  was malformed.

The errors were:

* .. code-block:: text

        1 validation error for ModuleDocSchema
        doc -> options -> data -> suboptions -> terminal -> suboptions -> password -> no_log
          Extra inputs are not permitted (type=extra_forbidden)


File a bug with the `cisco.radkit collection <https://wwwin-github.cisco.com/scdozier/cisco.radkit-ansible/issues>`_ in order to have it corrected.
