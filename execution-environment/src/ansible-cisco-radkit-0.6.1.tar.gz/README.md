# cisco.radkit

This cisco.radkit Ansible collection is a collection of plugins and modules that will connect through RADKit and/or utilize RADKit functions.

This project is currently in an beta, use at your own risk.

## Requires
* [radkit](https://radkit.cisco.com) 1.6 - Additionally, [setup certificate based login]([https://radkit.cisco.com/docs/pages/client_advanced.html#).
* python-proxy - Only if using the http_proxy module
## Installation
You can install directly via git:
```
ansible-galaxy collection install git+https://wwwin-github.cisco.com/scdozier/cisco.radkit-ansible.git
```
or from the tar file
```
ansible-galaxy collection install cisco-radkit-0.6.0.tar.gz
```

## Using Environment Variables

- All modules and plugins in this collection require variables to tell Ansible how to authentication with RADKit. Environment Variables are the preferred method, an example is shown below.

```
  export RADKIT_ANSIBLE_CLIENT_PRIVATE_KEY_PASSWORD_BASE64=$(echo -n 'mypassword' | base64)
  export RADKIT_ANSIBLE_IDENTITY="myuserid@cisco.com"
  export RADKIT_ANSIBLE_SERVICE_SERIAL="xxxx-xxx-xxxx"
```

## Known Issues

- Using network_cli with high number of forks gets errors "socket path /home/runner/.ansible/pc/aee792d3f8 does not exist or cannot be found. See Troubleshooting socket path issues"  
  WORKAROUNDS:

1.  Set a much longer timeout in ansible.cfg
2.  Try reducing the number of forks. Ansible network modules must execute modules locally which in combination with Radkit requires more CPU.
3.  Increase amount of CPU available on Ansible controller.
4.  If credentials are available, looking try using the port forwarding module instead of network_cli.

- On MacOS, error msg: "ERROR! A worker was found in a dead state" is seen. Note that this can happen with any ansible module and Mac.

WORKAROUND:

```
export no_proxy='*'
export OBJC_DISABLE_INITIALIZE_FORK_SAFETY=YES
```

(NOTE: This will not work in combination of HTTP Proxy module)

- Linux modules combined with the Terminal connection plugin must have passwordless sudo (add 'your_username ALL=(ALL:ALL) NOPASSWD:ALL' to /etc/sudoers)
- Network_cli plugin is faster than using terminal due to how Ansible network plugins can perform local persistent connections.  
  WORKAROUND:  
  If speed is an issue with Linux hosts, use port forwarding instead.

## Connection Plugins vs Modules vs Inventory Plugins

Connection Plugins allow you to utilize existing Ansible modules but connect through RADKIT instead of directly via SSH. With connection plugins,  
credentials to devices are stored on the remote RADKit service.

- network_cli -- Network_cli plugin is used for network devices with existing Ansible modules. Tested with ios, nxos.
- terminal -- Terminal plugin is used for non networking devices (LINUX) to SSH based modules.

Modules are specific tasks built upon RADKit functions. Some modules, such as http will require local credentials. The HTTP Proxy and Port Forward  
modules allow you to utilize nearly any existing ansible module with the caveat that you must send credentials to the device.

Inventory plugins allow you pull devices from the remote RADKIT service into your local Ansible inventory without manually building an inventory file.

This chart shows some of the differences:

|                                    | Terminal Connection Plugin | Network_CLI Plugin | Port Forward Module | HTTP Proxy Module | Swagger Module | Command/Genie Modules | HTTP Module |
| ---------------------------------- | -------------------------- | ------------------ | ------------------- | ----------------- | -------------- | --------------------- | ----------- |
| Device credentials stored locally  |                            |                    | X                   | X                 |                |                       | X           |
| Device credentials stored remotely | X                          | X                  |                     |                   | X              | X                     |             |
| Supports network cli modules       |                            | X                  | X                   |                   |                |                       |             |
| Supports linux ssh based modules   | X                          |                    | X                   |                   |                |                       |             |
| Supports http based modules        |                            |                    | X                   | X                 |                |                       |             |
| RADKIT Functions                   |                            |                    |                     |                   | X              | X                     | X           |

```
[persistent_connection]
command_timeout = 240
connect_timeout = 240
```

```
ansible-galaxy collection install cisco-radkit-0.6.0.tar.gz
```

```
ansible-galaxy collection install git+https://wwwin-github.cisco.com/scdozier/cisco.radkit-ansible.git
```
