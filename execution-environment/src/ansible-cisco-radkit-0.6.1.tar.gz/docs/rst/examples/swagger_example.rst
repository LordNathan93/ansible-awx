:orphan:


Swagger / OpenAPI
==============================


..  literalinclude:: ../../../playbooks/swagger.yml
    :language: yaml