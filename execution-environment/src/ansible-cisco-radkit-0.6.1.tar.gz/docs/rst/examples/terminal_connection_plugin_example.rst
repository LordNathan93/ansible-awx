:orphan:


Terminal Connection Plugin
==============================

Example Playbook
*********************************

..  literalinclude:: ../../../playbooks/terminal_connection_plugin_example.yml
    :language: yaml