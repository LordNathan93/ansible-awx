:orphan:


Genie Diff
==============================


..  literalinclude:: ../../../playbooks/genie_diff.yml
    :language: yaml