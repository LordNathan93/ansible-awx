
:orphan:

.. meta::
  :antsibull-docs: 2.6.1

.. _list_of_inventory_plugins:

Index of all Inventory Plugins
==============================

cisco.radkit
------------

* :ansplugin:`cisco.radkit.radkit#inventory` -- Ansible dynamic inventory plugin for RADKIT.

