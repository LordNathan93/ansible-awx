

.. meta::
  :antsibull-docs: 2.6.1


.. _plugins_in_cisco.radkit:

Cisco.Radkit
============

Collection version 0.5.2

.. contents::
   :local:
   :depth: 1

Description
-----------

Collection of plugins and modules for interacting with RADKit

**Author:**

* Scott Dozier <scdozier@cisco.com>

**Supported ansible-core versions:**

* 2.9.0 or newer

.. ansible-links::

  - title: "Issue Tracker"
    url: "https://wwwin-github.cisco.com/scdozier/cisco.radkit-ansible/issues"
    external: true
  - title: "Repository (Sources)"
    url: "https://wwwin-github.cisco.com/scdozier/cisco.radkit-ansible"
    external: true




.. toctree::
    :maxdepth: 1


Plugin Index
------------

These are the plugins in the cisco.radkit collection:


Modules
~~~~~~~

* :ansplugin:`command module <cisco.radkit.command#module>` -- Runs a command via RADKit and returns the result
* :ansplugin:`genie_diff module <cisco.radkit.genie_diff#module>` -- This module compares the results across multiple devices and outputs the differences.
* :ansplugin:`genie_learn module <cisco.radkit.genie_learn#module>` -- Runs a command via RADKit, then through genie parser, returning a parsed result
* :ansplugin:`genie_parsed_command module <cisco.radkit.genie_parsed_command#module>` -- Runs a command via RADKit, then through genie parser, returning a parsed result
* :ansplugin:`http module <cisco.radkit.http#module>` -- Interacts with HTTP and HTTPS web services via RADKit
* :ansplugin:`http_proxy module <cisco.radkit.http_proxy#module>` -- Starts a local HTTP (and SOCKS) proxy through RADKIT for use with modules that can utilize a proxy
* :ansplugin:`port_forward module <cisco.radkit.port_forward#module>` -- Forwards a port on a device in RADKIT inventory to localhost port.
* :ansplugin:`service_info module <cisco.radkit.service_info#module>` -- Gets RADKit service information and responds with status
* :ansplugin:`snmp module <cisco.radkit.snmp#module>` -- Gets information over SNMP via RADKit
* :ansplugin:`swagger module <cisco.radkit.swagger#module>` -- Interacts with Swagger/OpenAPI via RADKit

.. toctree::
    :maxdepth: 1
    :hidden:

    command_module
    genie_diff_module
    genie_learn_module
    genie_parsed_command_module
    http_module
    http_proxy_module
    port_forward_module
    service_info_module
    snmp_module
    swagger_module


Connection Plugins
~~~~~~~~~~~~~~~~~~

* :ansplugin:`network_cli connection <cisco.radkit.network_cli#connection>` -- Use network\_cli to run command on network appliances
* :ansplugin:`terminal connection <cisco.radkit.terminal#connection>` -- Run terminal (SSH) based tasks via RADKit

.. toctree::
    :maxdepth: 1
    :hidden:

    network_cli_connection
    terminal_connection


Inventory Plugins
~~~~~~~~~~~~~~~~~

* :ansplugin:`radkit inventory <cisco.radkit.radkit#inventory>` -- Ansible dynamic inventory plugin for RADKIT.

.. toctree::
    :maxdepth: 1
    :hidden:

    radkit_inventory



.. seealso::

    List of :ref:`collections <list_of_collections>` with docs hosted here.
