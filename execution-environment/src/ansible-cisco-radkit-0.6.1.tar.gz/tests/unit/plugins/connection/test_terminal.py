# Make coding more python3-ish
from __future__ import absolute_import, division, print_function

__metaclass__ = type

from unittest.mock import MagicMock, patch

import pytest
from ansible.errors import AnsibleError, AnsibleFileNotFound
from ansible.module_utils._text import to_bytes
from ansible.playbook.play_context import PlayContext
from ansible.plugins.loader import connection_loader
import radkit_client
try:
    from radkit_client.sync.context import create_context, certificate_login
    HAS_RADKIT = True
except ImportError:
    HAS_RADKIT = False

@pytest.fixture(name="conn")
def plugin_fixture():
    pc = PlayContext()
    pc.port = 8080
    pc.timeout = 60

    conn = connection_loader.get("cisco.radkit.terminal", pc, "/dev/null")
    return conn


def test_connect(conn, monkeypatch):
    """Test the libssh connection plugin.

    :param monkeypatch: pytest fixture
    """
    conn.set_options(
        direct={
            "radkit_service_serial": "xxxx",
            "radkit_identity": "xxxx",
            "radkit_client_private_key_password_base64": b"Cg==",
            "remote_addr": "testdevice",
            "remote_user": "user1",
            "password": "test",
            "host_key_checking": False,
        }
    )
    device = MagicMock()
    device.name = 'testdevice'
    device.host = '1.1.1.1'
    fake_inv =  {'testdevice': device}
    fake_inv_obj = MagicMock()
    fake_svc2_obj = MagicMock()
    fake_svc2_obj.inventory.return_value = fake_inv_obj
    fake_svc2_obj.inventory.filter.return_value = fake_inv
    fake_inv_obj.filter.return_value = fake_inv
    mock_radkit_client = MagicMock()
    def mock_certificate_login(identity, ca_path, key_path, cert_path, private_key_password):
        return mock_radkit_client
    class FakeSvcObj:
        def wait(time):
            return fake_svc2_obj
    def mock_connect():
        conn.inventory = fake_inv
        return device
    fake_svc_obj = FakeSvcObj()
    monkeypatch.setattr(conn, '_connect_uncached', mock_connect)
    mock_radkit_client.service.return_value = fake_svc_obj
    monkeypatch.setattr(radkit_client.sync.context, "certificate_login", mock_certificate_login)
    conn.device_filter = 'testdevice'
    conn._connect()
    assert conn.inventory == fake_inv
    assert conn.device.name == 'testdevice'



def test_close(conn):
    conn.device_filter = 'testdevice'
    conn.radkit_client = MagicMock()
    conn._session = MagicMock()
    conn._connected = True
    conn.close()
    conn.radkit_client.terminate.assert_called_with()
    conn._session.close.assert_called_with()



@patch("ansible.plugins.connection.ConnectionBase.exec_command")
def test_exec_command(mocked_super, conn):
    mock_radkit_device = MagicMock()
    mock_response =  MagicMock()
    mock_response.status = MagicMock()
    mock_response.status.value = 'SUCCESS'
    mock_response.result = MagicMock()
    mock_response.result.data = 'device#\nhello\ndevice#'
    mock_response.result.status_message = 'Executed command'
    class FakeExecObj:
        def wait(self):
            return mock_response
    fake_exec_obj = FakeExecObj()
    mock_radkit_device.exec = MagicMock()
    mock_radkit_device.exec.return_value = fake_exec_obj
    conn._connected = True
    conn.device = mock_radkit_device
    rc, out, err = conn.exec_command(cmd="echo hello")

    assert (rc, out, err) == (0, "hello", b"")


@patch("ansible.plugins.connection.ConnectionBase.put_file")
def test_put_file_not_exist(mocked_super, conn):
    with pytest.raises(AnsibleFileNotFound):
        conn._connected = True
        conn.put_file(in_path="", out_path="")


@patch("os.path.exists")
@patch("ansible.plugins.connection.ConnectionBase.put_file")
def test_put_file(mocked_super, mock_exists, conn):
    mock_radkit_device = MagicMock()
    mock_response =  MagicMock()
    mock_response.result = MagicMock()
    mock_response.result.status.value = 'TRANSFER_DONE'
    mock_response.bytes_written = 1234
    class FakeExecObj:
        def wait(self):
            return mock_response
    fake_exec_obj = FakeExecObj()
    mock_radkit_device.sftp_upload_from_file = MagicMock()
    mock_radkit_device.sftp_upload_from_file.return_value = fake_exec_obj
    file_path = "/"
    conn.device = mock_radkit_device
    conn._connected = True
    conn.put_file(in_path=file_path, out_path=file_path)
    mock_radkit_device.sftp_upload_from_file.assert_called_with(local_path=file_path, remote_path=file_path)


@patch("ansible.plugins.connection.ConnectionBase.fetch_file")
def test_fetch_file(mocked_super, conn):
    mock_radkit_device = MagicMock()
    mock_response =  MagicMock()
    mock_response.result = MagicMock()
    mock_response.result.status.value = 'TRANSFER_DONE'
    mock_response.bytes_written = 1234
    class FakeExecObj:
        def wait(self):
            return mock_response
    fake_exec_obj = FakeExecObj()
    mock_radkit_device.sftp_download_to_file = MagicMock()
    mock_radkit_device.sftp_download_to_file.return_value = fake_exec_obj
    file_path = "/"
    conn.device = mock_radkit_device
    conn._connected = True
    conn.fetch_file(in_path=file_path, out_path=file_path)
    mock_radkit_device.sftp_download_to_file.assert_called_with(remote_path=file_path, local_path=file_path)

