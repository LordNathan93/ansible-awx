# This file is part of RADKit / Lazy Maestro <radkit@cisco.com>
# Copyright (c) 2018-2023 by Cisco Systems, Inc.
# All rights reserved.

# isort: skip_file
from __future__ import annotations

import warnings

# This has to be the FIRST import from this module
# Add "noqa" to keep flake8 from complaining
from . import licensing  # noqa

# Do not display asyncssh warnings
warnings.filterwarnings(
    action="ignore",
    category=UserWarning,
    message="Blowfish|SEED|CAST5 has been deprecated",
)
