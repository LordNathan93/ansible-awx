# Pyarmor 8.5.12 (group), 006005, 2025-03-18T11:53:21.487610
from .pyarmor_runtime import __pyarmor__
