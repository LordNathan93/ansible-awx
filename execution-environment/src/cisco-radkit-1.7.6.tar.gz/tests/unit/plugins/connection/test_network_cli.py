#
# (c) 2016 Red Hat Inc.
# GNU General Public License v3.0+ (see LICENSES/GPL-3.0-or-later.txt or https://www.gnu.org/licenses/gpl-3.0.txt)
# SPDX-License-Identifier: GPL-3.0-or-later

# Make coding more python3-ish
from __future__ import absolute_import, division, print_function

__metaclass__ = type

import json
from unittest.mock import MagicMock
import time
import pytest
from ansible.errors import AnsibleConnectionFailure
from ansible.module_utils._text import to_text
from ansible.playbook.play_context import PlayContext
from ansible.plugins.loader import (
    connection_loader,
    terminal_loader,
)


@pytest.fixture(name="conn")
def plugin_fixture(monkeypatch):

    pc = PlayContext()
    pc.network_os = "fakeos"

    def get(*args, **kwargs):
        return MagicMock()

    monkeypatch.setattr(terminal_loader, "get", get)
    conn = connection_loader.get(
        "cisco.radkit.network_cli", pc, "/dev/null"
    )
    return conn


@pytest.mark.parametrize("network_os", [None, "invalid"])
def test_network_cli_invalid_os(network_os):
    pc = PlayContext()
    pc.network_os = network_os

    with pytest.raises(AnsibleConnectionFailure):
        connection_loader.get("cisco.radkit.network_cli", pc, "/dev/null")

@pytest.mark.parametrize(
    "become_method,become_pass", [("enable", "password"), (None, None)]
)
def test_network_cli__connect(conn, become_method, become_pass):
    conn.ssh = MagicMock()
    conn.receive = MagicMock()
    conn._terminal = MagicMock()
    conn._ssh_type_conn = MagicMock()

    if become_method:
        conn._play_context.become = True
        conn._play_context.become_method = become_method
        conn._play_context.become_pass = become_pass

    conn._connect()
    assert conn._ssh_type_conn._connect.called is True
    assert conn._terminal.on_open_shell.called is True
    if become_method:
        conn._terminal.on_become.assert_called_with(passwd=become_pass)
    else:
        assert conn._terminal.on_become.called is False


@pytest.mark.parametrize(
    "command", [json.dumps({"command": "command"})]
)
def test_network_cli_exec_command(conn, command):
    mock_send = MagicMock(return_value=b"command response")
    conn.send = mock_send
    conn._ssh_shell = MagicMock()
    conn._ssh_type_conn = MagicMock()

    out = conn.exec_command(command)

    mock_send.assert_called_with(command=b"command")
    assert out == b"command response"


@pytest.mark.parametrize(
    "response",
    [
        b"device#command\ncommand response\n\ndevice#",
        pytest.param(
            b"ERROR: error message device#",
            marks=pytest.mark.xfail(raises=AnsibleConnectionFailure),
        ),
    ],
)
@pytest.mark.parametrize("ssh_type", ["radkit"])
def test_network_cli_send(conn, response, ssh_type, monkeypatch):
    conn.set_options(
        direct={
            "radkit_service_serial": "xxxx",
            "radkit_identity": "xxxx",
            "radkit_client_private_key_password_base64": b"Cg==",
            "device_name": "somehost",
            "device_addr": "1.1.1.1",
            "terminal_stderr_re": [{"pattern": "^ERROR"}],
            "terminal_stdout_re": [{"pattern": "device#"}],
        }
    )
    mock__shell = MagicMock()

    conn._terminal = MagicMock()
    conn._ssh_shell = mock__shell
    conn._connected = True

    def write_with_delay(data):
        time.sleep(0.5)
    monkeypatch.setattr(conn.ssh_type_conn, 'write', write_with_delay)
    def read_with_delay(bytes_to_read=256, buffer_timeout=1):
        time.sleep(0.5)
        return response
    monkeypatch.setattr(conn.ssh_type_conn, 'read', read_with_delay)
    conn.send(b"command")
    assert to_text(conn._command_response) == "command response"


def test_network_cli_close(conn):
    conn._terminal = MagicMock()
    conn._ssh_shell = MagicMock()
    conn._ssh_type_conn = MagicMock()
    conn._connected = True
    conn.close()

    assert conn._connected is False
    assert conn._ssh_type_conn is None