#!/usr/bin/python
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)
from __future__ import (absolute_import, division, print_function)

DOCUMENTATION = '''
---
module: snmp
short_description: Gets information over SNMP via RADKit
version_added: "0.5.0"
description:
  - Gets information over SNMP via RADKit
options:
    device_name:
        description:
            - Name of device as it shows in RADKit inventory
        required: True
        type: str
    oid:
        description:
            - SNMP OID
        required: True
        type: str
    action:
        description:
            - Action to run on SNMP API. Supports either get or walk
        default: get
        type: str
    request_timeout:
        description:
            - Timeout for individual SNMP requests
        default: 10
        type: float
extends_documentation_fragment: cisco.radkit.radkit_client
requirements:
    - radkit
author: Scott Dozier (@scdozier)
'''

RETURN = r'''
data:
    description: SNMP Response
    returned: success
    type: list
'''
EXAMPLES = '''
    - name:  SNMP Walk device
      cisco.radkit.snmp:
        device_name: router1
        oid: 1.3.6.1.2.1.1
        action: walk
      register: snmp_output
      delegate_to: localhost
'''
import json
try:
    from radkit_client.sync import Client
    HAS_RADKIT = True
except ImportError:
    HAS_RADKIT = False
from ansible.module_utils.basic import AnsibleModule
from ansible_collections.cisco.radkit.plugins.module_utils.client import radkit_client_argument_spec, RadkitClientService
from ansible_collections.cisco.radkit.plugins.module_utils.exceptions import AnsibleRadkitError

__metaclass__ = type


def run_action(module: AnsibleModule, radkit_service: RadkitClientService):
    """
    Runs actions to execute commands via radkit service
    """
    results = {}
    err = False
    try:
        ansible = module.params
        if ansible['device_name']:
            # running exec on a single device
            inventory = radkit_service.get_inventory_by_filter(ansible['device_name'], 'name')
            if not inventory:
                raise AnsibleRadkitError(f"No devices found in RADKit inventory with attr: 'name' and pattern: {ansible['device_name']}!")
            # run snmp job
            snmp_func = getattr(inventory[ansible['device_name']].snmp, ansible['action'].lower())
            snmp_results = snmp_func(ansible['oid'], request_timeout=ansible['request_timeout']).wait().result
            return_data = []
            for row in snmp_results:
                return_data.append({'oid': snmp_results[row].oid_str, 'value': snmp_results[row].value})
            results['data'] = return_data
            results["changed"] = False
        else:
            err = True

    except Exception as e:
        err = True
        results["msg"] = str(e)
        results["changed"] = False

    return results, err


def main():
    spec = radkit_client_argument_spec()
    spec.update(dict(device_name=dict(type='str',
                                      required=True,
                                      ),
                     action=dict(type='str',
                                 default='get',
                                 ),
                     oid=dict(type='str',
                              required=True,
                              ),
                     request_timeout=dict(type='float',
                                          default='10',
                                          )
                     )
                )
    module = AnsibleModule(argument_spec=spec, supports_check_mode=False)
    if module.params['action'].lower() not in ['get', 'walk']:
        module.fail_json(msg='Action must be either get or walk')
    if not HAS_RADKIT:
        module.fail_json(msg='Python module cisco_radkit is required for this module!')
    with Client.create() as client:
        radkit_service = RadkitClientService(client, module.params)
        results, err = run_action(module, radkit_service)
    if err:
        module.fail_json(**results)
    module.exit_json(**results)


if __name__ == '__main__':
    main()
