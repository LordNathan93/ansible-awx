:orphan:


HTTP Proxy
==============================


..  literalinclude:: ../../../playbooks/http_proxy.yml
    :language: yaml