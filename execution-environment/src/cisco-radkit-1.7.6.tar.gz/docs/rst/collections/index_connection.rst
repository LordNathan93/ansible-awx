:orphan:

.. meta::
  :antsibull-docs: 2.16.1

.. _list_of_connection_plugins:

Index of all Connection Plugins
===============================

cisco.radkit
------------

* :ansplugin:`cisco.radkit.network_cli#connection` -- Use network\_cli to run command on network appliances
* :ansplugin:`cisco.radkit.terminal#connection` -- Run terminal (SSH) based tasks via RADKit
