.. meta::
  :antsibull-docs: 2.16.1

.. _list_of_collections_cisco:

Collections in the Cisco Namespace
==================================

These are the collections documented here in the **cisco** namespace.

* :ref:`cisco.radkit <plugins_in_cisco.radkit>`

.. toctree::
    :maxdepth: 1
    :hidden:

    radkit/index
