.. Document meta

:orphan:

.. |antsibull-internal-nbsp| unicode:: 0xA0
    :trim:

.. meta::
  :antsibull-docs: 2.16.1

.. Anchors

.. _ansible_collections.cisco.radkit.network_cli_connection:

.. Anchors: short name for ansible.builtin

.. Title

cisco.radkit.network_cli connection -- Use network\_cli to run command on network appliances
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

.. Collection note

.. note::
    This connection plugin is part of the `cisco.radkit collection <https://wwwin-github.cisco.com/scdozier/cisco.radkit-ansible>`_ (version 0.6.0).

    It is not included in ``ansible-core``.
    To check whether it is installed, run :code:`ansible-galaxy collection list`.

    To install it, use: :code:`ansible-galaxy collection install git+https://wwwin-github.cisco.com/scdozier/cisco.radkit-ansible.git`.
    You need further requirements to be able to use this connection plugin,
    see :ref:`Requirements <ansible_collections.cisco.radkit.network_cli_connection_requirements>` for details.

    To use it in a playbook, specify: :code:`cisco.radkit.network_cli`.

.. version_added

.. rst-class:: ansible-version-added

New in cisco.radkit 0.1.0

.. contents::
   :local:
   :depth: 1

.. Deprecated


Synopsis
--------

.. Description

- This connection plugin provides a connection to remote devices over the SSH through RADKit to implement a CLI shell. This connection plugin is typically used by network devices for sending and receiving CLI commands to network devices. Note that ansible\_host must be set in the inventory and match the host/ip in RADKit for the device.


.. Aliases


.. Requirements

.. _ansible_collections.cisco.radkit.network_cli_connection_requirements:

Requirements
------------
The below requirements are needed on the local controller node that executes this connection.

- radkit-client






.. Options

Parameters
----------

.. tabularcolumns:: \X{1}{3}\X{2}{3}

.. list-table::
  :width: 100%
  :widths: auto
  :header-rows: 1
  :class: longtable ansible-option-table

  * - Parameter
    - Comments

  * - .. raw:: html

        <div class="ansible-option-cell">
        <div class="ansibleOptionAnchor" id="parameter-become"></div>

      .. _ansible_collections.cisco.radkit.network_cli_connection__parameter-become:

      .. rst-class:: ansible-option-title

      **become**

      .. raw:: html

        <a class="ansibleOptionLink" href="#parameter-become" title="Permalink to this option"></a>

      .. ansible-option-type-line::

        :ansible-option-type:`boolean`




      .. raw:: html

        </div>

    - .. raw:: html

        <div class="ansible-option-cell">

      The become option will instruct the CLI session to attempt privilege escalation on platforms that support it. Normally this means transitioning from user mode to :literal:`enable` mode in the CLI session. If become is set to True and the remote device does not support privilege escalation or the privilege has already been elevated, then this option is silently ignored.

      Can be configured from the CLI via the :literal:`--become` or :literal:`-b` options.


      .. rst-class:: ansible-option-line

      :ansible-option-choices:`Choices:`

      - :ansible-option-choices-entry-default:`false` :ansible-option-choices-default-mark:`← (default)`
      - :ansible-option-choices-entry:`true`


      .. rst-class:: ansible-option-line

      :ansible-option-configuration:`Configuration:`

      - INI entry:

        .. code-block:: ini

          [privilege_escalation]
          become = false


      - Environment variable: :envvar:`ANSIBLE\_BECOME`

      - Variable: ansible\_become


      .. raw:: html

        </div>

  * - .. raw:: html

        <div class="ansible-option-cell">
        <div class="ansibleOptionAnchor" id="parameter-become_errors"></div>

      .. _ansible_collections.cisco.radkit.network_cli_connection__parameter-become_errors:

      .. rst-class:: ansible-option-title

      **become_errors**

      .. raw:: html

        <a class="ansibleOptionLink" href="#parameter-become_errors" title="Permalink to this option"></a>

      .. ansible-option-type-line::

        :ansible-option-type:`string`




      .. raw:: html

        </div>

    - .. raw:: html

        <div class="ansible-option-cell">

      This option determines how privilege escalation failures are handled when :emphasis:`become` is enabled.

      When set to :literal:`ignore`\ , the errors are silently ignored. When set to :literal:`warn`\ , a warning message is displayed. The default option :literal:`fail`\ , triggers a failure and halts execution.


      .. rst-class:: ansible-option-line

      :ansible-option-choices:`Choices:`

      - :ansible-option-choices-entry:`"ignore"`
      - :ansible-option-choices-entry:`"warn"`
      - :ansible-option-choices-entry-default:`"fail"` :ansible-option-choices-default-mark:`← (default)`


      .. rst-class:: ansible-option-line

      :ansible-option-configuration:`Configuration:`

      - Variable: ansible\_network\_become\_errors


      .. raw:: html

        </div>

  * - .. raw:: html

        <div class="ansible-option-cell">
        <div class="ansibleOptionAnchor" id="parameter-become_method"></div>

      .. _ansible_collections.cisco.radkit.network_cli_connection__parameter-become_method:

      .. rst-class:: ansible-option-title

      **become_method**

      .. raw:: html

        <a class="ansibleOptionLink" href="#parameter-become_method" title="Permalink to this option"></a>

      .. ansible-option-type-line::

        :ansible-option-type:`string`




      .. raw:: html

        </div>

    - .. raw:: html

        <div class="ansible-option-cell">

      This option allows the become method to be specified in for handling privilege escalation. Typically the become\_method value is set to :literal:`enable` but could be defined as other values.


      .. rst-class:: ansible-option-line

      :ansible-option-default-bold:`Default:` :ansible-option-default:`"sudo"`

      .. rst-class:: ansible-option-line

      :ansible-option-configuration:`Configuration:`

      - INI entry:

        .. code-block:: ini

          [privilege_escalation]
          become_method = sudo


      - Environment variable: :envvar:`ANSIBLE\_BECOME\_METHOD`

      - Variable: ansible\_become\_method


      .. raw:: html

        </div>

  * - .. raw:: html

        <div class="ansible-option-cell">
        <div class="ansibleOptionAnchor" id="parameter-device_addr"></div>

      .. _ansible_collections.cisco.radkit.network_cli_connection__parameter-device_addr:

      .. rst-class:: ansible-option-title

      **device_addr**

      .. raw:: html

        <a class="ansibleOptionLink" href="#parameter-device_addr" title="Permalink to this option"></a>

      .. ansible-option-type-line::

        :ansible-option-type:`string` / :ansible-option-required:`required`




      .. raw:: html

        </div>

    - .. raw:: html

        <div class="ansible-option-cell">

      Hostname/Address of the remote target. This must match the host on RADKit.

      This option will be used when ansible\_host or ansible\_ssh\_host is specified


      .. rst-class:: ansible-option-line

      :ansible-option-configuration:`Configuration:`

      - Variable: ansible\_host

      - Variable: ansible\_ssh\_host


      .. raw:: html

        </div>

  * - .. raw:: html

        <div class="ansible-option-cell">
        <div class="ansibleOptionAnchor" id="parameter-device_name"></div>

      .. _ansible_collections.cisco.radkit.network_cli_connection__parameter-device_name:

      .. rst-class:: ansible-option-title

      **device_name**

      .. raw:: html

        <a class="ansibleOptionLink" href="#parameter-device_name" title="Permalink to this option"></a>

      .. ansible-option-type-line::

        :ansible-option-type:`string` / :ansible-option-required:`required`




      .. raw:: html

        </div>

    - .. raw:: html

        <div class="ansible-option-cell">

      Device name of the remote target. This must match the device name in RADKit if ansible\_host not set.


      .. rst-class:: ansible-option-line

      :ansible-option-configuration:`Configuration:`

      - Variable: inventory\_hostname


      .. raw:: html

        </div>

  * - .. raw:: html

        <div class="ansible-option-cell">
        <div class="ansibleOptionAnchor" id="parameter-import_modules"></div>

      .. _ansible_collections.cisco.radkit.network_cli_connection__parameter-import_modules:

      .. rst-class:: ansible-option-title

      **import_modules**

      .. raw:: html

        <a class="ansibleOptionLink" href="#parameter-import_modules" title="Permalink to this option"></a>

      .. ansible-option-type-line::

        :ansible-option-type:`boolean`




      .. raw:: html

        </div>

    - .. raw:: html

        <div class="ansible-option-cell">

      Reduce CPU usage and network module execution time by enabling direct execution. Instead of the module being packaged and executed by the shell, it will be directly executed by the Ansible control node using the same python interpreter as the Ansible process. Note- Incompatible with :literal:`asynchronous mode`. Note- Python 3 and Ansible 2.9.16 or greater required. Note- With Ansible 2.9.x fully qualified modules names are required in tasks.


      .. rst-class:: ansible-option-line

      :ansible-option-choices:`Choices:`

      - :ansible-option-choices-entry:`false`
      - :ansible-option-choices-entry-default:`true` :ansible-option-choices-default-mark:`← (default)`


      .. rst-class:: ansible-option-line

      :ansible-option-configuration:`Configuration:`

      - INI entry:

        .. code-block:: ini

          [ansible_network]
          import_modules = true


      - Environment variable: :envvar:`ANSIBLE\_NETWORK\_IMPORT\_MODULES`

      - Variable: ansible\_network\_import\_modules


      .. raw:: html

        </div>

  * - .. raw:: html

        <div class="ansible-option-cell">
        <div class="ansibleOptionAnchor" id="parameter-network_cli_retries"></div>

      .. _ansible_collections.cisco.radkit.network_cli_connection__parameter-network_cli_retries:

      .. rst-class:: ansible-option-title

      **network_cli_retries**

      .. raw:: html

        <a class="ansibleOptionLink" href="#parameter-network_cli_retries" title="Permalink to this option"></a>

      .. ansible-option-type-line::

        :ansible-option-type:`integer`




      .. raw:: html

        </div>

    - .. raw:: html

        <div class="ansible-option-cell">

      Number of attempts to connect to remote host. The delay time between the retires increases after every attempt by power of 2 in seconds till either the maximum attempts are exhausted or any of the :literal:`persistent\_command\_timeout` or :literal:`persistent\_connect\_timeout` timers are triggered.


      .. rst-class:: ansible-option-line

      :ansible-option-default-bold:`Default:` :ansible-option-default:`3`

      .. rst-class:: ansible-option-line

      :ansible-option-configuration:`Configuration:`

      - INI entry:

        .. code-block:: ini

          [persistent_connection]
          network_cli_retries = 3


      - Environment variable: :envvar:`ANSIBLE\_NETWORK\_CLI\_RETRIES`

      - Variable: ansible\_network\_cli\_retries


      .. raw:: html

        </div>

  * - .. raw:: html

        <div class="ansible-option-cell">
        <div class="ansibleOptionAnchor" id="parameter-network_os"></div>

      .. _ansible_collections.cisco.radkit.network_cli_connection__parameter-network_os:

      .. rst-class:: ansible-option-title

      **network_os**

      .. raw:: html

        <a class="ansibleOptionLink" href="#parameter-network_os" title="Permalink to this option"></a>

      .. ansible-option-type-line::

        :ansible-option-type:`string`




      .. raw:: html

        </div>

    - .. raw:: html

        <div class="ansible-option-cell">

      Configures the device platform network operating system. This value is used to load the correct terminal and cliconf plugins to communicate with the remote device.


      .. rst-class:: ansible-option-line

      :ansible-option-configuration:`Configuration:`

      - Variable: ansible\_network\_os


      .. raw:: html

        </div>

  * - .. raw:: html

        <div class="ansible-option-cell">
        <div class="ansibleOptionAnchor" id="parameter-persistent_buffer_read_timeout"></div>

      .. _ansible_collections.cisco.radkit.network_cli_connection__parameter-persistent_buffer_read_timeout:

      .. rst-class:: ansible-option-title

      **persistent_buffer_read_timeout**

      .. raw:: html

        <a class="ansibleOptionLink" href="#parameter-persistent_buffer_read_timeout" title="Permalink to this option"></a>

      .. ansible-option-type-line::

        :ansible-option-type:`float`




      .. raw:: html

        </div>

    - .. raw:: html

        <div class="ansible-option-cell">

      Configures, in seconds, the amount of time to wait for the data to be read from Radkit interactive session after the command prompt is matched. This timeout value ensures that command prompt matched is correct and there is no more data left to be received from remote host.


      .. rst-class:: ansible-option-line

      :ansible-option-default-bold:`Default:` :ansible-option-default:`0.5`

      .. rst-class:: ansible-option-line

      :ansible-option-configuration:`Configuration:`

      - INI entry:

        .. code-block:: ini

          [persistent_connection]
          buffer_read_timeout = 0.5


      - Environment variable: :envvar:`ANSIBLE\_PERSISTENT\_BUFFER\_READ\_TIMEOUT`

      - Variable: ansible\_buffer\_read\_timeout


      .. raw:: html

        </div>

  * - .. raw:: html

        <div class="ansible-option-cell">
        <div class="ansibleOptionAnchor" id="parameter-persistent_command_timeout"></div>

      .. _ansible_collections.cisco.radkit.network_cli_connection__parameter-persistent_command_timeout:

      .. rst-class:: ansible-option-title

      **persistent_command_timeout**

      .. raw:: html

        <a class="ansibleOptionLink" href="#parameter-persistent_command_timeout" title="Permalink to this option"></a>

      .. ansible-option-type-line::

        :ansible-option-type:`integer`




      .. raw:: html

        </div>

    - .. raw:: html

        <div class="ansible-option-cell">

      Configures, in seconds, the amount of time to wait for a command to return from the remote device. If this timer is exceeded before the command returns, the connection plugin will raise an exception and close.


      .. rst-class:: ansible-option-line

      :ansible-option-default-bold:`Default:` :ansible-option-default:`30`

      .. rst-class:: ansible-option-line

      :ansible-option-configuration:`Configuration:`

      - INI entry:

        .. code-block:: ini

          [persistent_connection]
          command_timeout = 30


      - Environment variable: :envvar:`ANSIBLE\_PERSISTENT\_COMMAND\_TIMEOUT`

      - Variable: ansible\_command\_timeout


      .. raw:: html

        </div>

  * - .. raw:: html

        <div class="ansible-option-cell">
        <div class="ansibleOptionAnchor" id="parameter-persistent_connect_timeout"></div>

      .. _ansible_collections.cisco.radkit.network_cli_connection__parameter-persistent_connect_timeout:

      .. rst-class:: ansible-option-title

      **persistent_connect_timeout**

      .. raw:: html

        <a class="ansibleOptionLink" href="#parameter-persistent_connect_timeout" title="Permalink to this option"></a>

      .. ansible-option-type-line::

        :ansible-option-type:`integer`




      .. raw:: html

        </div>

    - .. raw:: html

        <div class="ansible-option-cell">

      Configures, in seconds, the amount of time to wait when trying to initially establish a persistent connection. If this value expires before the connection to the remote device is completed, the connection will fail.


      .. rst-class:: ansible-option-line

      :ansible-option-default-bold:`Default:` :ansible-option-default:`30`

      .. rst-class:: ansible-option-line

      :ansible-option-configuration:`Configuration:`

      - INI entry:

        .. code-block:: ini

          [persistent_connection]
          connect_timeout = 30


      - Environment variable: :envvar:`ANSIBLE\_PERSISTENT\_CONNECT\_TIMEOUT`

      - Variable: ansible\_connect\_timeout


      .. raw:: html

        </div>

  * - .. raw:: html

        <div class="ansible-option-cell">
        <div class="ansibleOptionAnchor" id="parameter-persistent_log_messages"></div>

      .. _ansible_collections.cisco.radkit.network_cli_connection__parameter-persistent_log_messages:

      .. rst-class:: ansible-option-title

      **persistent_log_messages**

      .. raw:: html

        <a class="ansibleOptionLink" href="#parameter-persistent_log_messages" title="Permalink to this option"></a>

      .. ansible-option-type-line::

        :ansible-option-type:`boolean`




      .. raw:: html

        </div>

    - .. raw:: html

        <div class="ansible-option-cell">

      This flag will enable logging the command executed and response received from target device in the ansible log file. For this option to work 'log\_path' ansible configuration option is required to be set to a file path with write access.

      Be sure to fully understand the security implications of enabling this option as it could create a security vulnerability by logging sensitive information in log file.


      .. rst-class:: ansible-option-line

      :ansible-option-choices:`Choices:`

      - :ansible-option-choices-entry-default:`false` :ansible-option-choices-default-mark:`← (default)`
      - :ansible-option-choices-entry:`true`


      .. rst-class:: ansible-option-line

      :ansible-option-configuration:`Configuration:`

      - INI entry:

        .. code-block:: ini

          [persistent_connection]
          log_messages = false


      - Environment variable: :envvar:`ANSIBLE\_PERSISTENT\_LOG\_MESSAGES`

      - Variable: ansible\_persistent\_log\_messages


      .. raw:: html

        </div>

  * - .. raw:: html

        <div class="ansible-option-cell">
        <div class="ansibleOptionAnchor" id="parameter-radkit_client_ca_path"></div>

      .. _ansible_collections.cisco.radkit.network_cli_connection__parameter-radkit_client_ca_path:

      .. rst-class:: ansible-option-title

      **radkit_client_ca_path**

      .. raw:: html

        <a class="ansibleOptionLink" href="#parameter-radkit_client_ca_path" title="Permalink to this option"></a>

      .. ansible-option-type-line::

        :ansible-option-type:`string`




      .. raw:: html

        </div>

    - .. raw:: html

        <div class="ansible-option-cell">

      The path to the issuer chain for the identity certificate


      .. rst-class:: ansible-option-line

      :ansible-option-configuration:`Configuration:`

      - Environment variable: :envvar:`RADKIT\_ANSIBLE\_CLIENT\_CA\_PATH`

      - Variable: radkit\_client\_ca\_path


      .. raw:: html

        </div>

  * - .. raw:: html

        <div class="ansible-option-cell">
        <div class="ansibleOptionAnchor" id="parameter-radkit_client_cert_path"></div>

      .. _ansible_collections.cisco.radkit.network_cli_connection__parameter-radkit_client_cert_path:

      .. rst-class:: ansible-option-title

      **radkit_client_cert_path**

      .. raw:: html

        <a class="ansibleOptionLink" href="#parameter-radkit_client_cert_path" title="Permalink to this option"></a>

      .. ansible-option-type-line::

        :ansible-option-type:`string`




      .. raw:: html

        </div>

    - .. raw:: html

        <div class="ansible-option-cell">

      The path to the identity certificate


      .. rst-class:: ansible-option-line

      :ansible-option-configuration:`Configuration:`

      - Environment variable: :envvar:`RADKIT\_ANSIBLE\_CLIENT\_CERT\_PATH`

      - Variable: radkit\_client\_cert\_path


      .. raw:: html

        </div>

  * - .. raw:: html

        <div class="ansible-option-cell">
        <div class="ansibleOptionAnchor" id="parameter-radkit_client_key_path"></div>

      .. _ansible_collections.cisco.radkit.network_cli_connection__parameter-radkit_client_key_path:

      .. rst-class:: ansible-option-title

      **radkit_client_key_path**

      .. raw:: html

        <a class="ansibleOptionLink" href="#parameter-radkit_client_key_path" title="Permalink to this option"></a>

      .. ansible-option-type-line::

        :ansible-option-type:`string`




      .. raw:: html

        </div>

    - .. raw:: html

        <div class="ansible-option-cell">

      The path to the private key for the identity certificate


      .. rst-class:: ansible-option-line

      :ansible-option-configuration:`Configuration:`

      - Environment variable: :envvar:`RADKIT\_ANSIBLE\_CLIENT\_KEY\_PATH`

      - Variable: radkit\_client\_key\_path


      .. raw:: html

        </div>

  * - .. raw:: html

        <div class="ansible-option-cell">
        <div class="ansibleOptionAnchor" id="parameter-radkit_client_private_key_password_base64"></div>

      .. _ansible_collections.cisco.radkit.network_cli_connection__parameter-radkit_client_private_key_password_base64:

      .. rst-class:: ansible-option-title

      **radkit_client_private_key_password_base64**

      .. raw:: html

        <a class="ansibleOptionLink" href="#parameter-radkit_client_private_key_password_base64" title="Permalink to this option"></a>

      .. ansible-option-type-line::

        :ansible-option-type:`string` / :ansible-option-required:`required`




      .. raw:: html

        </div>

    - .. raw:: html

        <div class="ansible-option-cell">

      The private key password in base64 for radkit client


      .. rst-class:: ansible-option-line

      :ansible-option-configuration:`Configuration:`

      - Environment variable: :envvar:`RADKIT\_ANSIBLE\_CLIENT\_PRIVATE\_KEY\_PASSWORD\_BASE64`

      - Variable: radkit\_client\_private\_key\_password\_base64


      .. raw:: html

        </div>

  * - .. raw:: html

        <div class="ansible-option-cell">
        <div class="ansibleOptionAnchor" id="parameter-radkit_identity"></div>

      .. _ansible_collections.cisco.radkit.network_cli_connection__parameter-radkit_identity:

      .. rst-class:: ansible-option-title

      **radkit_identity**

      .. raw:: html

        <a class="ansibleOptionLink" href="#parameter-radkit_identity" title="Permalink to this option"></a>

      .. ansible-option-type-line::

        :ansible-option-type:`string` / :ansible-option-required:`required`




      .. raw:: html

        </div>

    - .. raw:: html

        <div class="ansible-option-cell">

      The Client ID (owner email address) present in the RADKit client certificate.


      .. rst-class:: ansible-option-line

      :ansible-option-configuration:`Configuration:`

      - Environment variable: :envvar:`RADKIT\_ANSIBLE\_IDENTITY`

      - Variable: radkit\_identity


      .. raw:: html

        </div>

  * - .. raw:: html

        <div class="ansible-option-cell">
        <div class="ansibleOptionAnchor" id="parameter-radkit_service_serial"></div>

      .. _ansible_collections.cisco.radkit.network_cli_connection__parameter-radkit_service_serial:

      .. rst-class:: ansible-option-title

      **radkit_service_serial**

      .. raw:: html

        <a class="ansibleOptionLink" href="#parameter-radkit_service_serial" title="Permalink to this option"></a>

      .. ansible-option-type-line::

        :ansible-option-type:`string` / :ansible-option-required:`required`




      .. raw:: html

        </div>

    - .. raw:: html

        <div class="ansible-option-cell">

      The serial of the RADKit service you wish to connect through


      .. rst-class:: ansible-option-line

      :ansible-option-configuration:`Configuration:`

      - Environment variable: :envvar:`RADKIT\_ANSIBLE\_SERVICE\_SERIAL`

      - Variable: radkit\_service\_serial


      .. raw:: html

        </div>

  * - .. raw:: html

        <div class="ansible-option-cell">
        <div class="ansibleOptionAnchor" id="parameter-single_user_mode"></div>

      .. _ansible_collections.cisco.radkit.network_cli_connection__parameter-single_user_mode:

      .. rst-class:: ansible-option-title

      **single_user_mode**

      .. raw:: html

        <a class="ansibleOptionLink" href="#parameter-single_user_mode" title="Permalink to this option"></a>

      .. ansible-option-type-line::

        :ansible-option-type:`boolean`

      :ansible-option-versionadded:`added in cisco.radkit 2.0.0`





      .. raw:: html

        </div>

    - .. raw:: html

        <div class="ansible-option-cell">

      This option enables caching of data fetched from the target for re-use. The cache is invalidated when the target device enters configuration mode.

      Applicable only for platforms where this has been implemented.


      .. rst-class:: ansible-option-line

      :ansible-option-choices:`Choices:`

      - :ansible-option-choices-entry-default:`false` :ansible-option-choices-default-mark:`← (default)`
      - :ansible-option-choices-entry:`true`


      .. rst-class:: ansible-option-line

      :ansible-option-configuration:`Configuration:`

      - Environment variable: :envvar:`ANSIBLE\_NETWORK\_SINGLE\_USER\_MODE`

      - Variable: ansible\_network\_single\_user\_mode


      .. raw:: html

        </div>

  * - .. raw:: html

        <div class="ansible-option-cell">
        <div class="ansibleOptionAnchor" id="parameter-terminal_errors"></div>

      .. _ansible_collections.cisco.radkit.network_cli_connection__parameter-terminal_errors:

      .. rst-class:: ansible-option-title

      **terminal_errors**

      .. raw:: html

        <a class="ansibleOptionLink" href="#parameter-terminal_errors" title="Permalink to this option"></a>

      .. ansible-option-type-line::

        :ansible-option-type:`string`

      :ansible-option-versionadded:`added in cisco.radkit 3.1.0`





      .. raw:: html

        </div>

    - .. raw:: html

        <div class="ansible-option-cell">

      This option determines how failures while setting terminal parameters are handled.

      When set to :literal:`ignore`\ , the errors are silently ignored. When set to :literal:`warn`\ , a warning message is displayed. The default option :literal:`fail`\ , triggers a failure and halts execution.


      .. rst-class:: ansible-option-line

      :ansible-option-choices:`Choices:`

      - :ansible-option-choices-entry:`"ignore"`
      - :ansible-option-choices-entry:`"warn"`
      - :ansible-option-choices-entry-default:`"fail"` :ansible-option-choices-default-mark:`← (default)`


      .. rst-class:: ansible-option-line

      :ansible-option-configuration:`Configuration:`

      - Variable: ansible\_network\_terminal\_errors


      .. raw:: html

        </div>

  * - .. raw:: html

        <div class="ansible-option-cell">
        <div class="ansibleOptionAnchor" id="parameter-terminal_inital_prompt_newline"></div>

      .. _ansible_collections.cisco.radkit.network_cli_connection__parameter-terminal_inital_prompt_newline:

      .. rst-class:: ansible-option-title

      **terminal_inital_prompt_newline**

      .. raw:: html

        <a class="ansibleOptionLink" href="#parameter-terminal_inital_prompt_newline" title="Permalink to this option"></a>

      .. ansible-option-type-line::

        :ansible-option-type:`boolean`




      .. raw:: html

        </div>

    - .. raw:: html

        <div class="ansible-option-cell">

      This boolean flag, that when set to :emphasis:`True` will send newline in the response if any of values in :emphasis:`terminal\_initial\_prompt` is matched.


      .. rst-class:: ansible-option-line

      :ansible-option-choices:`Choices:`

      - :ansible-option-choices-entry:`false`
      - :ansible-option-choices-entry-default:`true` :ansible-option-choices-default-mark:`← (default)`


      .. rst-class:: ansible-option-line

      :ansible-option-configuration:`Configuration:`

      - Variable: ansible\_terminal\_initial\_prompt\_newline


      .. raw:: html

        </div>

  * - .. raw:: html

        <div class="ansible-option-cell">
        <div class="ansibleOptionAnchor" id="parameter-terminal_initial_answer"></div>

      .. _ansible_collections.cisco.radkit.network_cli_connection__parameter-terminal_initial_answer:

      .. rst-class:: ansible-option-title

      **terminal_initial_answer**

      .. raw:: html

        <a class="ansibleOptionLink" href="#parameter-terminal_initial_answer" title="Permalink to this option"></a>

      .. ansible-option-type-line::

        :ansible-option-type:`list` / :ansible-option-elements:`elements=string`




      .. raw:: html

        </div>

    - .. raw:: html

        <div class="ansible-option-cell">

      The answer to reply with if the :literal:`terminal\_initial\_prompt` is matched. The value can be a single answer or a list of answers for multiple terminal\_initial\_prompt. In case the login menu has multiple prompts the sequence of the prompt and excepted answer should be in same order and the value of :emphasis:`terminal\_prompt\_checkall` should be set to :emphasis:`True` if all the values in :literal:`terminal\_initial\_prompt` are expected to be matched and set to :emphasis:`False` if any one login prompt is to be matched.


      .. rst-class:: ansible-option-line

      :ansible-option-configuration:`Configuration:`

      - Variable: ansible\_terminal\_initial\_answer


      .. raw:: html

        </div>

  * - .. raw:: html

        <div class="ansible-option-cell">
        <div class="ansibleOptionAnchor" id="parameter-terminal_initial_prompt"></div>

      .. _ansible_collections.cisco.radkit.network_cli_connection__parameter-terminal_initial_prompt:

      .. rst-class:: ansible-option-title

      **terminal_initial_prompt**

      .. raw:: html

        <a class="ansibleOptionLink" href="#parameter-terminal_initial_prompt" title="Permalink to this option"></a>

      .. ansible-option-type-line::

        :ansible-option-type:`list` / :ansible-option-elements:`elements=string`




      .. raw:: html

        </div>

    - .. raw:: html

        <div class="ansible-option-cell">

      A single regex pattern or a sequence of patterns to evaluate the expected prompt at the time of initial login to the remote host.


      .. rst-class:: ansible-option-line

      :ansible-option-configuration:`Configuration:`

      - Variable: ansible\_terminal\_initial\_prompt


      .. raw:: html

        </div>

  * - .. raw:: html

        <div class="ansible-option-cell">
        <div class="ansibleOptionAnchor" id="parameter-terminal_initial_prompt_checkall"></div>

      .. _ansible_collections.cisco.radkit.network_cli_connection__parameter-terminal_initial_prompt_checkall:

      .. rst-class:: ansible-option-title

      **terminal_initial_prompt_checkall**

      .. raw:: html

        <a class="ansibleOptionLink" href="#parameter-terminal_initial_prompt_checkall" title="Permalink to this option"></a>

      .. ansible-option-type-line::

        :ansible-option-type:`boolean`




      .. raw:: html

        </div>

    - .. raw:: html

        <div class="ansible-option-cell">

      By default the value is set to :emphasis:`False` and any one of the prompts mentioned in :literal:`terminal\_initial\_prompt` option is matched it won't check for other prompts. When set to :emphasis:`True` it will check for all the prompts mentioned in :literal:`terminal\_initial\_prompt` option in the given order and all the prompts should be received from remote host if not it will result in timeout.


      .. rst-class:: ansible-option-line

      :ansible-option-choices:`Choices:`

      - :ansible-option-choices-entry-default:`false` :ansible-option-choices-default-mark:`← (default)`
      - :ansible-option-choices-entry:`true`


      .. rst-class:: ansible-option-line

      :ansible-option-configuration:`Configuration:`

      - Variable: ansible\_terminal\_initial\_prompt\_checkall


      .. raw:: html

        </div>

  * - .. raw:: html

        <div class="ansible-option-cell">
        <div class="ansibleOptionAnchor" id="parameter-terminal_stderr_re"></div>

      .. _ansible_collections.cisco.radkit.network_cli_connection__parameter-terminal_stderr_re:

      .. rst-class:: ansible-option-title

      **terminal_stderr_re**

      .. raw:: html

        <a class="ansibleOptionLink" href="#parameter-terminal_stderr_re" title="Permalink to this option"></a>

      .. ansible-option-type-line::

        :ansible-option-type:`list` / :ansible-option-elements:`elements=dictionary`




      .. raw:: html

        </div>

    - .. raw:: html

        <div class="ansible-option-cell">

      This option provides the regex pattern and optional flags to match the error string from the received response chunk. This option accepts :literal:`pattern` and :literal:`flags` keys. The value of :literal:`pattern` is a python regex pattern to match the response and the value of :literal:`flags` is the value accepted by :emphasis:`flags` argument of :emphasis:`re.compile` python method to control the way regex is matched with the response, for example :emphasis:`'re.I'`.


      .. rst-class:: ansible-option-line

      :ansible-option-configuration:`Configuration:`

      - Variable: ansible\_terminal\_stderr\_re


      .. raw:: html

        </div>

  * - .. raw:: html

        <div class="ansible-option-cell">
        <div class="ansibleOptionAnchor" id="parameter-terminal_stdout_re"></div>

      .. _ansible_collections.cisco.radkit.network_cli_connection__parameter-terminal_stdout_re:

      .. rst-class:: ansible-option-title

      **terminal_stdout_re**

      .. raw:: html

        <a class="ansibleOptionLink" href="#parameter-terminal_stdout_re" title="Permalink to this option"></a>

      .. ansible-option-type-line::

        :ansible-option-type:`list` / :ansible-option-elements:`elements=dictionary`




      .. raw:: html

        </div>

    - .. raw:: html

        <div class="ansible-option-cell">

      A single regex pattern or a sequence of patterns along with optional flags to match the command prompt from the received response chunk. This option accepts :literal:`pattern` and :literal:`flags` keys. The value of :literal:`pattern` is a python regex pattern to match the response and the value of :literal:`flags` is the value accepted by :emphasis:`flags` argument of :emphasis:`re.compile` python method to control the way regex is matched with the response, for example :emphasis:`'re.I'`.


      .. rst-class:: ansible-option-line

      :ansible-option-configuration:`Configuration:`

      - Variable: ansible\_terminal\_stdout\_re


      .. raw:: html

        </div>


.. Attributes


.. Notes


.. Seealso


.. Examples

Examples
--------

.. code-block:: yaml+jinja

    - hosts: all
      connection: cisco.radkit.network_cli
      vars:
        radkit_service_serial: xxxx-xxxx-xxxx
        radkit_identity: user@cisco.com
        ansible_network_os: ios
      become: yes
      tasks:
        - name: Gather all ios facts
          cisco.ios.ios_facts:
            gather_subset: all

        - debug:
            msg: "{{ ansible_facts }}"

        - name: Run show version
          cisco.ios.ios_command:
            commands: show version



.. Facts


.. Return values


..  Status (Presently only deprecated)


.. Authors

Authors
~~~~~~~

- Ansible Networking Team (@ansible-network)
- Scott Dozier (@scdozier)


.. hint::
    Configuration entries for each entry type have a low to high priority order. For example, a variable that is lower in the list will override a variable that is higher up.

.. Extra links

Collection links
~~~~~~~~~~~~~~~~

.. ansible-links::

  - title: "Issue Tracker"
    url: "https://wwwin-github.cisco.com/scdozier/cisco.radkit-ansible/issues"
    external: true
  - title: "Repository (Sources)"
    url: "https://wwwin-github.cisco.com/scdozier/cisco.radkit-ansible"
    external: true


.. Parsing errors
