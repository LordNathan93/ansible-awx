.. Document meta

:orphan:

.. |antsibull-internal-nbsp| unicode:: 0xA0
    :trim:

.. meta::
  :antsibull-docs: 2.16.1

.. Anchors

.. _ansible_collections.cisco.radkit.terminal_connection:

.. Anchors: short name for ansible.builtin

.. Title

cisco.radkit.terminal connection -- Run terminal (SSH) based tasks via RADKit
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

.. Collection note

.. note::
    This connection plugin is part of the `cisco.radkit collection <https://wwwin-github.cisco.com/scdozier/cisco.radkit-ansible>`_ (version 0.6.0).

    It is not included in ``ansible-core``.
    To check whether it is installed, run :code:`ansible-galaxy collection list`.

    To install it, use: :code:`ansible-galaxy collection install git+https://wwwin-github.cisco.com/scdozier/cisco.radkit-ansible.git`.

    To use it in a playbook, specify: :code:`cisco.radkit.terminal`.

.. version_added

.. rst-class:: ansible-version-added

New in cisco.radkit 0.1.0

.. contents::
   :local:
   :depth: 1

.. Deprecated


Synopsis
--------

.. Description

- Uses RADKit to connect to devices over SSH. Works with LINUX platforms.


.. Aliases


.. Requirements






.. Options

Parameters
----------

.. tabularcolumns:: \X{1}{3}\X{2}{3}

.. list-table::
  :width: 100%
  :widths: auto
  :header-rows: 1
  :class: longtable ansible-option-table

  * - Parameter
    - Comments

  * - .. raw:: html

        <div class="ansible-option-cell">
        <div class="ansibleOptionAnchor" id="parameter-device_addr"></div>

      .. _ansible_collections.cisco.radkit.terminal_connection__parameter-device_addr:

      .. rst-class:: ansible-option-title

      **device_addr**

      .. raw:: html

        <a class="ansibleOptionLink" href="#parameter-device_addr" title="Permalink to this option"></a>

      .. ansible-option-type-line::

        :ansible-option-type:`string`




      .. raw:: html

        </div>

    - .. raw:: html

        <div class="ansible-option-cell">

      Hostname/Address of the remote target. This must match the host on RADKit.

      This option will be used when ansible\_host or ansible\_ssh\_host is specified


      .. rst-class:: ansible-option-line

      :ansible-option-configuration:`Configuration:`

      - Variable: ansible\_host

      - Variable: ansible\_ssh\_host


      .. raw:: html

        </div>

  * - .. raw:: html

        <div class="ansible-option-cell">
        <div class="ansibleOptionAnchor" id="parameter-device_name"></div>

      .. _ansible_collections.cisco.radkit.terminal_connection__parameter-device_name:

      .. rst-class:: ansible-option-title

      **device_name**

      .. raw:: html

        <a class="ansibleOptionLink" href="#parameter-device_name" title="Permalink to this option"></a>

      .. ansible-option-type-line::

        :ansible-option-type:`string`




      .. raw:: html

        </div>

    - .. raw:: html

        <div class="ansible-option-cell">

      Device name of the remote target. This must match the device name on RADKit (not host field)


      .. rst-class:: ansible-option-line

      :ansible-option-configuration:`Configuration:`

      - Variable: inventory\_hostname


      .. raw:: html

        </div>

  * - .. raw:: html

        <div class="ansible-option-cell">
        <div class="ansibleOptionAnchor" id="parameter-radkit_client_ca_path"></div>

      .. _ansible_collections.cisco.radkit.terminal_connection__parameter-radkit_client_ca_path:

      .. rst-class:: ansible-option-title

      **radkit_client_ca_path**

      .. raw:: html

        <a class="ansibleOptionLink" href="#parameter-radkit_client_ca_path" title="Permalink to this option"></a>

      .. ansible-option-type-line::

        :ansible-option-type:`string`




      .. raw:: html

        </div>

    - .. raw:: html

        <div class="ansible-option-cell">

      The path to the issuer chain for the identity certificate


      .. rst-class:: ansible-option-line

      :ansible-option-configuration:`Configuration:`

      - Environment variable: :envvar:`RADKIT\_ANSIBLE\_CLIENT\_CA\_PATH`

      - Variable: radkit\_client\_ca\_path


      .. raw:: html

        </div>

  * - .. raw:: html

        <div class="ansible-option-cell">
        <div class="ansibleOptionAnchor" id="parameter-radkit_client_cert_path"></div>

      .. _ansible_collections.cisco.radkit.terminal_connection__parameter-radkit_client_cert_path:

      .. rst-class:: ansible-option-title

      **radkit_client_cert_path**

      .. raw:: html

        <a class="ansibleOptionLink" href="#parameter-radkit_client_cert_path" title="Permalink to this option"></a>

      .. ansible-option-type-line::

        :ansible-option-type:`string`




      .. raw:: html

        </div>

    - .. raw:: html

        <div class="ansible-option-cell">

      The path to the identity certificate


      .. rst-class:: ansible-option-line

      :ansible-option-configuration:`Configuration:`

      - Environment variable: :envvar:`RADKIT\_ANSIBLE\_CLIENT\_CERT\_PATH`

      - Variable: radkit\_client\_cert\_path


      .. raw:: html

        </div>

  * - .. raw:: html

        <div class="ansible-option-cell">
        <div class="ansibleOptionAnchor" id="parameter-radkit_client_key_path"></div>

      .. _ansible_collections.cisco.radkit.terminal_connection__parameter-radkit_client_key_path:

      .. rst-class:: ansible-option-title

      **radkit_client_key_path**

      .. raw:: html

        <a class="ansibleOptionLink" href="#parameter-radkit_client_key_path" title="Permalink to this option"></a>

      .. ansible-option-type-line::

        :ansible-option-type:`string`




      .. raw:: html

        </div>

    - .. raw:: html

        <div class="ansible-option-cell">

      The path to the private key for the identity certificate


      .. rst-class:: ansible-option-line

      :ansible-option-configuration:`Configuration:`

      - Environment variable: :envvar:`RADKIT\_ANSIBLE\_CLIENT\_KEY\_PATH`

      - Variable: radkit\_client\_key\_path


      .. raw:: html

        </div>

  * - .. raw:: html

        <div class="ansible-option-cell">
        <div class="ansibleOptionAnchor" id="parameter-radkit_client_private_key_password_base64"></div>

      .. _ansible_collections.cisco.radkit.terminal_connection__parameter-radkit_client_private_key_password_base64:

      .. rst-class:: ansible-option-title

      **radkit_client_private_key_password_base64**

      .. raw:: html

        <a class="ansibleOptionLink" href="#parameter-radkit_client_private_key_password_base64" title="Permalink to this option"></a>

      .. ansible-option-type-line::

        :ansible-option-type:`string` / :ansible-option-required:`required`




      .. raw:: html

        </div>

    - .. raw:: html

        <div class="ansible-option-cell">

      The private key password in base64 for radkit client


      .. rst-class:: ansible-option-line

      :ansible-option-configuration:`Configuration:`

      - Environment variable: :envvar:`RADKIT\_ANSIBLE\_CLIENT\_PRIVATE\_KEY\_PASSWORD\_BASE64`

      - Variable: radkit\_client\_private\_key\_password\_base64


      .. raw:: html

        </div>

  * - .. raw:: html

        <div class="ansible-option-cell">
        <div class="ansibleOptionAnchor" id="parameter-radkit_exec_timeout"></div>

      .. _ansible_collections.cisco.radkit.terminal_connection__parameter-radkit_exec_timeout:

      .. rst-class:: ansible-option-title

      **radkit_exec_timeout**

      .. raw:: html

        <a class="ansibleOptionLink" href="#parameter-radkit_exec_timeout" title="Permalink to this option"></a>

      .. ansible-option-type-line::

        :ansible-option-type:`integer`




      .. raw:: html

        </div>

    - .. raw:: html

        <div class="ansible-option-cell">

      Specifies how many seconds RADKit will for wait command to complete


      .. rst-class:: ansible-option-line

      :ansible-option-default-bold:`Default:` :ansible-option-default:`3600`

      .. rst-class:: ansible-option-line

      :ansible-option-configuration:`Configuration:`

      - Environment variable: :envvar:`RADKIT\_ANSIBLE\_EXEC\_TIMEOUT`

      - Variable: radkit\_exec\_timeout


      .. raw:: html

        </div>

  * - .. raw:: html

        <div class="ansible-option-cell">
        <div class="ansibleOptionAnchor" id="parameter-radkit_identity"></div>

      .. _ansible_collections.cisco.radkit.terminal_connection__parameter-radkit_identity:

      .. rst-class:: ansible-option-title

      **radkit_identity**

      .. raw:: html

        <a class="ansibleOptionLink" href="#parameter-radkit_identity" title="Permalink to this option"></a>

      .. ansible-option-type-line::

        :ansible-option-type:`string` / :ansible-option-required:`required`




      .. raw:: html

        </div>

    - .. raw:: html

        <div class="ansible-option-cell">

      The Client ID (owner email address) present in the RADKit client certificate.


      .. rst-class:: ansible-option-line

      :ansible-option-configuration:`Configuration:`

      - Environment variable: :envvar:`RADKIT\_ANSIBLE\_IDENTITY`

      - Variable: radkit\_identity


      .. raw:: html

        </div>

  * - .. raw:: html

        <div class="ansible-option-cell">
        <div class="ansibleOptionAnchor" id="parameter-radkit_service_serial"></div>

      .. _ansible_collections.cisco.radkit.terminal_connection__parameter-radkit_service_serial:

      .. rst-class:: ansible-option-title

      **radkit_service_serial**

      .. raw:: html

        <a class="ansibleOptionLink" href="#parameter-radkit_service_serial" title="Permalink to this option"></a>

      .. ansible-option-type-line::

        :ansible-option-type:`string` / :ansible-option-required:`required`




      .. raw:: html

        </div>

    - .. raw:: html

        <div class="ansible-option-cell">

      The serial of the RADKit service you wish to connect through


      .. rst-class:: ansible-option-line

      :ansible-option-configuration:`Configuration:`

      - Environment variable: :envvar:`RADKIT\_ANSIBLE\_SERVICE\_SERIAL`

      - Variable: radkit\_service\_serial


      .. raw:: html

        </div>

  * - .. raw:: html

        <div class="ansible-option-cell">
        <div class="ansibleOptionAnchor" id="parameter-radkit_wait_timeout"></div>

      .. _ansible_collections.cisco.radkit.terminal_connection__parameter-radkit_wait_timeout:

      .. rst-class:: ansible-option-title

      **radkit_wait_timeout**

      .. raw:: html

        <a class="ansibleOptionLink" href="#parameter-radkit_wait_timeout" title="Permalink to this option"></a>

      .. ansible-option-type-line::

        :ansible-option-type:`integer`




      .. raw:: html

        </div>

    - .. raw:: html

        <div class="ansible-option-cell">

      Specifies how many seconds RADKit will wait before failing task.

      Note that the request is not affected, and it will still eventually complete (successfully or unsuccessfully)


      .. rst-class:: ansible-option-line

      :ansible-option-default-bold:`Default:` :ansible-option-default:`0`

      .. rst-class:: ansible-option-line

      :ansible-option-configuration:`Configuration:`

      - Environment variable: :envvar:`RADKIT\_ANSIBLE\_WAIT\_TIMEOUT`

      - Variable: radkit\_wait\_timeout


      .. raw:: html

        </div>


.. Attributes


.. Notes


.. Seealso


.. Examples

Examples
--------

.. code-block:: yaml+jinja

    - hosts: all
      connection: cisco.radkit.terminal
      vars:
        ansible_remote_tmp: /tmp/.ansible/tmp
        ansible_async_dir: /tmp/.ansible_async
        radkit_service_serial: xxxx-xxxx-xxxx
        radkit_identity: user@cisco.com
      become: yes
      tasks:
        - name: Restart sshd
          ansible.builtin.service:
            name: sshd
            state: restarted



.. Facts


.. Return values


..  Status (Presently only deprecated)


.. Authors

Authors
~~~~~~~

- Ansible Core Team
- Scott Dozier (@scdozier)


.. hint::
    Configuration entries for each entry type have a low to high priority order. For example, a variable that is lower in the list will override a variable that is higher up.

.. Extra links

Collection links
~~~~~~~~~~~~~~~~

.. ansible-links::

  - title: "Issue Tracker"
    url: "https://wwwin-github.cisco.com/scdozier/cisco.radkit-ansible/issues"
    external: true
  - title: "Repository (Sources)"
    url: "https://wwwin-github.cisco.com/scdozier/cisco.radkit-ansible"
    external: true


.. Parsing errors
