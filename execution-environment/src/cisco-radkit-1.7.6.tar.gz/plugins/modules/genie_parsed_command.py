#!/usr/bin/python
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)
from __future__ import (absolute_import, division, print_function)

DOCUMENTATION = '''
---
module: genie_parsed_command
short_description: Runs a command via RADKit, then through genie parser, returning a parsed result
version_added: "0.2.0"
description:
  - Runs a command via RADKit, then through genie parser, returning a parsed result
options:
    device_name:
        description:
            - Name of device as it shows in RADKit inventory
        required: False
        type: str
    filter_pattern:
        description:
            - Pattern to match RADKit inventory, which can select multiple devices at once. (use instead of device_name)
        required: False
        type: str
    filter_attr:
        description:
            - Attrbute to match RADKit inventory, which can select multiple devices at once. (use with filter_pattern, ex 'name')
        required: False
        type: str
    commands:
        description:
            - Commands to execute on device
        required: True
        type: list
        elements: str
    os:
        description:
            -  The device OS (if omitted, the OS found by fingerprint)
        default: fingerprint
        type: str
    wait_timeout:
        description:
            - Specifies how many seconds RADKit will wait before failing task.
            - Note that the request is not affected, and it will still eventually complete (successfully or unsuccessfully)
            - Can optionally set via environemnt variable RADKIT_ANSIBLE_WAIT_TIMEOUT
        required: False
        default: 0
        type: int
    exec_timeout:
        description:
            - Specifies how many seconds RADKit will for command to complete
            - Can optionally set via environemnt variable RADKIT_ANSIBLE_EXEC_TIMEOUT
        required: False
        default: 0
        type: int
    remove_cmd_and_device_keys:
        description:
            - Removes the command and device keys from the returned value when running a single command against a single device.
            - NOTE; This does not work with diff
        default: False
        type: bool
extends_documentation_fragment: cisco.radkit.radkit_client
requirements:
    - radkit
author: Scott Dozier (@scdozier)
'''

RETURN = r'''
device_name:
    description: Device in Radkit
    returned: success
    type: str
command:
    description: Command
    returned: success
    type: str
exec_status:
    description: Status of exec from RADKit
    returned: success
    type: str
exec_status_message:
    description: Status message from RADKit
    returned: success
    type: str
ansible_module_results:
    description: Dictionary of results is returned if running command on multiple devices or with multiple commands
    returned: success
    type: dict
genie_parsed_result:
    description: Dictionary of parsed results
    returned: success
    type: dict
'''
EXAMPLES = '''
- name:  Get parsed output from all routers starting with rtr-
  cisco.radkit.genie_parsed_command:
    commands: show version
    filter_pattern: rtr-
    filter_attr: name
    os: iosxe
  register: cmd_output
  delegate_to: localhost

- name: Show output
  debug:
    msg: "{{ cmd_output }}"

- name: Get parsed output from rtr-csr1 with removed return keys
  cisco.radkit.genie_parsed_command:
    device_name: rtr-csr1
    commands: show version
    os: iosxe
    remove_cmd_and_device_keys: yes
  register: cmd_output
  delegate_to: localhost

- name: Show IOS version
  debug:
    msg: "{{ cmd_output['genie_parsed_result']['version']['version'] }}"


'''
try:
    from radkit_client.sync import Client
    HAS_RADKIT = True
except ImportError:
    HAS_RADKIT = False
from ansible.module_utils.basic import AnsibleModule
from ansible_collections.cisco.radkit.plugins.module_utils.client import radkit_client_argument_spec, RadkitClientService
from ansible_collections.cisco.radkit.plugins.module_utils.exceptions import AnsibleRadkitError
from ansible.module_utils.basic import env_fallback
try:
    import radkit_genie
    HAS_RADKIT_GENIE = True
except ImportError:
    HAS_RADKIT_GENIE = False
__metaclass__ = type


def run_action(module: AnsibleModule, radkit_service: RadkitClientService):
    """
    Runs actions to execute commands via radkit service
    """
    results = {}
    err = False
    try:
        ansible = module.params
        results['ansible_module_results'] = {}
        ansible_returned_result = {}
        if ansible['device_name']:
            # running exec on a single device
            inventory = radkit_service.get_inventory_by_filter(ansible['device_name'], 'name')
            if not inventory:
                raise AnsibleRadkitError(f"No devices found in RADKit inventory with attr: 'name' and pattern: {ansible['device_name']}!")

            response = radkit_service.exec_command(ansible['commands'],
                                                   inventory,
                                                   return_full_response=True)
            radkit_result = response.result
            radkit_result = radkit_result[ansible['device_name']]
            ansible_returned_result = []

            for command in radkit_result:
                cmd_result = radkit_result[command]
                cmd_result_dict = {'device_name': cmd_result.device.name,
                                   'command': cmd_result.command,
                                   'exec_status': cmd_result.status.value,
                                   'exec_status_message': cmd_result.status_message,
                                   }
                ansible_returned_result.append(cmd_result_dict)
                if radkit_result.status.value != 'SUCCESS':
                    raise AnsibleRadkitError(f'{radkit_result.status_message}')

            if ansible['os'] == 'fingerprint':
                radkit_genie.fingerprint(inventory)
                genie_parsed_result = radkit_genie.parse(response)

            else:
                genie_parsed_result = radkit_genie.parse(response, os=ansible['os'])
            if ansible['remove_cmd_and_device_keys'] and len(radkit_result.keys()) == 1:
                results['genie_parsed_result'] = genie_parsed_result.to_dict()[ansible['device_name']][ansible['commands'][0]]
            else:
                results['genie_parsed_result'] = genie_parsed_result.to_dict()
            if len(ansible_returned_result) == 1:
                ansible_returned_result = ansible_returned_result[0]
        else:
            # running exec on multiple devices, returns a list of dicts
            ansible_returned_result = []
            inventory = radkit_service.get_inventory_by_filter(ansible['filter_pattern'], ansible['filter_attr'])
            if not inventory:
                raise AnsibleRadkitError("No devices found in RADKit inventory with attr: " +
                                         f"{ansible['filter_attr']} and pattern: {ansible['filter_pattern']}!")
            response = radkit_service.exec_command(ansible['commands'],
                                                   inventory, return_full_response=True)
            radkit_result = response.result
            device_statuses = set([radkit_result[d].status.value for d in radkit_result])
            if len(device_statuses) == 1 and list(device_statuses)[0] == 'FAILURE':
                err = True
                results["msg"] = 'All devices failed to connect via RADKIT. Check connectivity and/or authentication'
            else:
                for device in radkit_result:
                    for command in radkit_result[device]:
                        cmd_result = radkit_result[device][command]
                        cmd_result_dict = {'device_name': cmd_result.device.name,
                                           'command': cmd_result.command,
                                           'exec_status': cmd_result.status.value,
                                           'exec_status_message': cmd_result.status_message,
                                           }
                        ansible_returned_result.append(cmd_result_dict)

                    # do genie parsing on inventory
                    genie_parsed_result = {}
                    if ansible['os'] == 'fingerprint':
                        radkit_genie.fingerprint(inventory)
                        genie_parsed_result = radkit_genie.parse(response, skip_unknown_os=True)
                    else:
                        genie_parsed_result = radkit_genie.parse(response, os=ansible['os'])

                if ansible['remove_cmd_and_device_keys'] and len(genie_parsed_result.keys()) == 1 and len(ansible['commands']) == 1:
                    results['genie_parsed_result'] = genie_parsed_result.to_dict()[list(genie_parsed_result.keys())[0]][ansible['commands'][0]]
                else:
                    results['genie_parsed_result'] = genie_parsed_result.to_dict()
        results['changed'] = False

    except Exception as e:
        err = True
        results["msg"] = str(e)
        results["changed"] = False

    if isinstance(ansible_returned_result, list):
        results['ansible_module_results'] = ansible_returned_result
    elif isinstance(ansible_returned_result, dict):
        results.update(ansible_returned_result)
    return results, err


def main():
    spec = radkit_client_argument_spec()
    spec.update(dict(commands=dict(type='list',
                                   elements='str',
                                   required=True,
                                   ),
                     device_name=dict(type='str',
                                      required=False,
                                      ),
                     os=dict(type='str',
                             default='fingerprint',
                             ),
                     filter_pattern=dict(type='str',
                                         required=False,
                                         ),
                     filter_attr=dict(type='str',
                                      required=False,
                                      ),
                     wait_timeout=dict(type='int',
                                       default=0,
                                       fallback=(env_fallback, ['RADKIT_ANSIBLE_WAIT_TIMEOUT'])
                                       ),
                     exec_timeout=dict(type='int',
                                       default=0,
                                       fallback=(env_fallback, ['RADKIT_ANSIBLE_EXEC_TIMEOUT'])
                                       ),
                     remove_cmd_and_device_keys=dict(type='bool',
                                                     default=False,
                                                     ),
                     )
                )
    module = AnsibleModule(argument_spec=spec, supports_check_mode=False)
    if not module.params['device_name'] and not module.params['filter_pattern'] and not module.params['filter_attr']:
        module.fail_json(msg='You must provide either argument device_name or filter_pattern+filter_attr')
    if not module.params['device_name'] and (module.params['filter_pattern'] and not module.params['filter_attr']):
        module.fail_json(msg='You must provide either provide BOTH filter_pattern and filter_attr')
    if not HAS_RADKIT:
        module.fail_json(msg='Python module cisco_radkit is required for this module!')
    with Client.create() as client:
        radkit_service = RadkitClientService(client, module.params)
        results, err = run_action(module, radkit_service)
    if err:
        module.fail_json(**results)
    module.exit_json(**results)


if __name__ == '__main__':
    main()
