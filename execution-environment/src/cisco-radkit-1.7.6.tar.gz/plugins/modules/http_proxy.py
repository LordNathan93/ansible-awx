#!/usr/bin/python
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)
from __future__ import (absolute_import, division, print_function)

DOCUMENTATION = '''
---
module: http_proxy
short_description: Starts a local HTTP (and SOCKS) proxy through RADKIT for use with modules that can utilize a proxy
version_added: "0.3.0"
description:
  - This modules starts a local HTTP (and SOCKS) proxy through RADKIT for use with modules that can utilize a proxy.
  - RADKIT can natively create a SOCKS proxy, but most Ansible modules only support HTTP proxy if at all, so this module starts both.
  - Note that the proxy will ONLY forward connections to devices that have a forwarded port in RADKIT AND to hosts in format of <hostname>.<serial>.proxy.
options:
    http_proxy_port:
        description:
            - HTTP proxy port opened by module
        default: '4001'
        type: str
    socks_proxy_port:
        description:
            - SOCKS proxy port opened by RADKIT client
        default: '4000'
        type: str
    proxy_username:
        description:
            - Username for use with both http and socks proxy.
            - If the value is not specified in the task, the value of environment variable RADKIT_ANSIBLE_PROXY_USERNAME will be used instead.
        type: str
        required: True
    proxy_password:
        description:
            - Password for use with both http and socks proxy
            - If the value is not specified in the task, the value of environment variable RADKIT_ANSIBLE_PROXY_PASSWORD will be used instead.
        type: str
        required: True
    test:
        description:
            - Tests your proxy configuration before trying to run in async
        type: bool
        default: False
extends_documentation_fragment: cisco.radkit.radkit_client
requirements:
    - radkit
    - python-proxy
author: Scott Dozier (@scdozier)
'''

EXAMPLES = '''
# The idea of this module is to start the module once and run on localhost for duration of the play.
# Any other module running on the localhost can utilize it to connect to devices over HTTPS.
#
# Note that connecting through the proxy in radkit is of format <device name>.<serial>.proxy
---
- hosts: all
  gather_facts: no
  vars:
    radkit_service_serial: xxxx-xxxx-xxxx
    http_proxy_username: radkit
    http_proxy_password: Radkit999
    http_proxy_port: 4001
    socks_proxy_port: 4000
  environment:
    http_proxy: "http://{{ http_proxy_username }}:{{ http_proxy_password }}@127.0.0.1:{{ http_proxy_port }}"
    https_proxy: "http://{{ http_proxy_username }}:{{ http_proxy_password }}@127.0.0.1:{{ http_proxy_port }}"
  pre_tasks:

    - name: Test HTTP Proxy RADKIT To Find Potential Config Errors (optional)
      cisco.radkit.http_proxy:
        http_proxy_port: "{{ http_proxy_port }}"
        socks_proxy_port: "{{ socks_proxy_port }}"
        proxy_username: "{{ http_proxy_username }}"
        proxy_password: "{{ http_proxy_password }}"
        test: True
      delegate_to: localhost
      run_once: true

    - name: Start HTTP Proxy Through RADKIT And Leave Running for 300 Seconds (adjust time based on playbook exec time)
      cisco.radkit.http_proxy:
        http_proxy_port: "{{ http_proxy_port }}"
        socks_proxy_port: "{{ socks_proxy_port }}"
        proxy_username: "{{ http_proxy_username }}"
        proxy_password: "{{ http_proxy_password }}"
      async: 300
      poll: 0
      delegate_to: localhost
      run_once: true

    - name: Wait for http proxy port to become open (it takes a little bit for proxy to start)
      ansible.builtin.wait_for:
        port: "{{ http_proxy_port }}"
        delay: 1
      delegate_to: localhost
      run_once: true

  tasks:

    - name: Example ACI Task that goes through http proxy
      cisco.aci.aci_system:
        hostname:  "{{ inventory_hostname }}.{{ radkit_service_serial }}.proxy"
        username: admin
        password: "password"
        state: query
        use_proxy: yes
        validate_certs: no
      delegate_to: localhost
      failed_when: False


'''
RETURN = r'''
'''
import asyncio
try:
    import pproxy
    HAS_PPROXY = True
except ImportError:
    HAS_PPROXY = False
try:
    from radkit_client.sync import Client
    HAS_RADKIT = True
except ImportError:
    HAS_RADKIT = False
from ansible.module_utils.basic import AnsibleModule
from ansible_collections.cisco.radkit.plugins.module_utils.client import radkit_client_argument_spec, RadkitClientService
from ansible.module_utils.basic import env_fallback

__metaclass__ = type


def run_action(module: AnsibleModule, radkit_service: RadkitClientService):
    """
    Runs starts a HTTP and SOCKS Proxy throgh RADKIT
    """
    results = {}
    err = False
    try:
        ansible = module.params
        results['ansible_module_results'] = {}
        ansible_returned_result = {}
        # start socks proxy in radkit
        radkit_service.radkit_client.start_socks_proxy(ansible['socks_proxy_port'],
                                                       username=ansible['proxy_username'],
                                                       password=ansible['proxy_password'])
        # start http proxy that will forward through radkit socks proxy
        server = pproxy.Server('http://0.0.0.0:{0}#{1}:{2}'.format(ansible["http_proxy_port"],
                                                                   ansible["proxy_username"],
                                                                   ansible["proxy_password"],
                                                                   ))
        remote = pproxy.Connection('socks5://127.0.0.1:{0}#{1}:{2}'.format(ansible["socks_proxy_port"],
                                                                           ansible["proxy_username"],
                                                                           ansible["proxy_password"],
                                                                           ))
        args = dict(rserver=[remote], verbose=print)

        loop = asyncio.get_event_loop()
        handler = loop.run_until_complete(server.start_server(args))
        if not ansible['test']:
            try:
                loop.run_forever()
            except KeyboardInterrupt:
                module.debug('KeyboardInterrupt!')

        handler.close()
        loop.run_until_complete(handler.wait_closed())
        loop.run_until_complete(loop.shutdown_asyncgens())
        loop.close()
        if ansible['test']:
            results['changed'] = False
            radkit_service.radkit_client.stop_socks_proxy()
        else:
            results['changed'] = True

    except Exception as e:
        err = True
        results["msg"] = str(e)
        results["changed"] = False

    if isinstance(ansible_returned_result, list):
        results['ansible_module_results'] = ansible_returned_result
    elif isinstance(ansible_returned_result, dict):
        results.update(ansible_returned_result)
    return results, err


def main():
    spec = radkit_client_argument_spec()
    spec.update(dict(test=dict(type='bool',
                               default=False,
                               ),
                     http_proxy_port=dict(type='str',
                                          default='4001',
                                          ),
                     socks_proxy_port=dict(type='str',
                                           default='4000',
                                           ),
                     proxy_username=dict(type='str',
                                         required=True,
                                         fallback=(env_fallback, ['RADKIT_ANSIBLE_PROXY_USERNAME'])
                                         ),
                     proxy_password=dict(type='str',
                                         required=True,
                                         no_log=True,
                                         fallback=(env_fallback, ['RADKIT_ANSIBLE_PROXY_PASSWORD'])
                                         ),
                     )
                )
    module = AnsibleModule(argument_spec=spec, supports_check_mode=False)
    if not HAS_PPROXY:
        module.fail_json(msg='Python module pproxy is required for this module!')
    if module.params['http_proxy_port'] == module.params['socks_proxy_port']:
        module.fail_json(msg='http_proxy_port and socks_proxy_port cannot be the same!')
    if not HAS_RADKIT:
        module.fail_json(msg='Python module cisco_radkit is required for this module!')
    with Client.create() as client:
        radkit_service = RadkitClientService(client, module.params)
        results, err = run_action(module, radkit_service)
    if err:
        module.fail_json(**results)
    module.exit_json(**results)


if __name__ == '__main__':
    main()
